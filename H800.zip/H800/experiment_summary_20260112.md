# 实验进展与结果汇总（Parallel-R1 / GSM8K & MedQA）

更新时间：2026-01-12  
仓库路径：`/home/maqiang/workshop/parallel-r1`

> 本文汇总：数据处理、SFT 训练、评测脚本与指标、关键实验结果（含论文口径 Mean@k/Pass@k）、checkpoint 与日志清单、RL 训练尝试与问题定位。

---

## 1. 已完成的任务总览

### 1.1 数据处理
- **MedQA（US_4options）** 原始数据已转换为 Parallel-R1 训练/评测所需 Parquet schema（含 `extra_info.question/answer`、`reward_model.ground_truth` 等）。
- 产出目录：
  - `verl/data_preprocess_scripts/data/med_qa/medqa_us_4options_parallel_v1/`
    - `train.parquet`
    - `valid.parquet`
    - `test.parquet`

### 1.2 SFT 训练
- **GSM8K SFT（5 epoch）**：完成并落盘 checkpoint（`global_step_230` 等）。
- **MedQA SFT（1 epoch）**：完成并落盘 checkpoint（`global_step_80`）。
- **MedQA SFT（5 epoch）**：曾运行（日志存在），但训练中途失败/未保留可用 checkpoint 目录。

### 1.3 评测体系建设
- `verl/eval/medqa_eval.py`
  - 支持 MedQA 多选题抽取（`Final Answer: <A-E>`）。
  - 扩展支持 **多采样**：输出 `acc@1 / Mean@k / Pass@k`，并附带诊断指标：
    - `parsed_ratio`：预测可解析比例（pred != None）
    - `final_answer_ratio`：输出中包含 `Final Answer:` 的比例
    - `parallel_ratio`：输出中出现并行标签的比例（当前实现是“文本标签出现率”的粗统计）
- `verl/eval/gsm8k_eval.py`
  - 扩展支持 **多采样**：输出 `acc@1 / Mean@k / Pass@k`，用于对齐论文常用的多采样评测口径。

### 1.4 排障/复现（关键经验）
- **SFT OOM**：通过 `MAX_LENGTH=2048`、`TRUNCATION=right` 与调整 micro-batch 等解决。
- **日志实时 tail 不显示**：定位为 `tqdm` + `grep` 缓冲问题（line-buffer 解决）。
- **“看似跑完实则 crash”**：通过检查日志错误栈、checkpoint 目录确认真实状态。
- **重要结论**：**评测口径决定你能否“看见”SFT 的真实差距**：单次贪心/单样本可能掩盖差异，使用 `Mean@k / Pass@k`（如 k=16）差距更清晰。

---

## 2. 关键产物/路径清单

### 2.1 数据
- MedQA parquet：  
  `verl/data_preprocess_scripts/data/med_qa/medqa_us_4options_parallel_v1/`
- GSM8K parquet（test）：  
  `verl/data_preprocess_scripts/data/gsm8k/adaptive_parallel_thinking_final_with_prompt_v3/rl_all_accuracy_times_parallel_reward/test.parquet`

### 2.2 SFT checkpoint

#### MedQA SFT（1 epoch）
- `verl/Parallel-R1/MedQA-SFT-US4-mb2-ep1_20260106_152444/global_step_80/`
- `verl/Parallel-R1/MedQA-SFT-US4-mb2-ep1_20260105_174057/global_step_80/`

#### GSM8K SFT（5 epoch）
- `verl/Parallel-R1/Parallel-SFT-Unseen-official_MAX2048_20260105_015427/global_step_230/`
- 另有同一实验下多个 step：
  - `global_step_{46,92,138,184,230}`

### 2.3 训练日志
- 日志目录：`verl/logs/`
- MedQA 5 epoch（失败的那次）：
  - `verl/logs/sft_medqa_us4_20260105_165231.log`（配置显示 5 epoch / 400 steps，但目录未保留）

### 2.4 评测输出
- 目录：`verl/eval_outputs/`
- 每个评测目录通常包含：
  - `predictions.jsonl`（逐样本输出）
  - `summary.json`（汇总指标）
  - `config.json`（评测配置）

---

## 3. 实验结果汇总（已完成）

> 说明：以下结果全部来自对应 `eval_outputs/**/summary.json`。

### 3.1 MedQA test（单次生成口径）

| 模型 | accuracy | 正确数/总数 | 评测目录 |
|---|---:|---:|---|
| Base | 0.2757 | 351/1273 | `eval_outputs/medqa_base_20260106_152444/` |
| MedQA SFT 1ep (gs80) | 0.2781 | 354/1273 | `eval_outputs/medqa_sft_gs80_20260106_152444/` |

**结论**：单次口径下差距很小（+0.24pct），容易误判 “SFT 没效果”。

### 3.2 MedQA test（论文口径：k=16 采样）

| 模型 | acc@1 | Mean@16 | Pass@16 | final_answer_ratio | parallel_ratio | 评测目录 |
|---|---:|---:|---:|---:|---:|---|
| Base | 0.1579 | 0.1778 | 0.8940 | 0.4311 | 1.0 | `eval_outputs/medqa_base_k16_20260106/` |
| MedQA SFT 1ep (gs80) | **0.2514** | **0.2539** | **0.9874** | **0.99995** | 1.0 | `eval_outputs/medqa_sft_gs80_k16_20260106/` |

**差距（SFT - Base）**
- acc@1：+0.0935
- Mean@16：+0.0761
- Pass@16：+0.0934
- `final_answer_ratio`：+0.5688（格式遵从性提升巨大，是性能提升的重要来源之一）

### 3.3 GSM8K test（论文口径：k=16 采样）

| 模型 | acc@1 | Mean@16 | Pass@16 | parsed_ratio | final_answer_ratio | parallel_ratio | 评测目录 |
|---|---:|---:|---:|---:|---:|---:|---|
| Base | 0.1903 | 0.2038 | 0.7263 | 0.99981 | 1.0 | 0.0 | `eval_outputs/gsm8k_base_k16_20260107/` |
| GSM8K SFT 5ep (gs230) | **0.5049** | **0.5077** | **0.8976** | 0.99991 | 1.0 | 0.0 | `eval_outputs/gsm8k_sft5ep_k16_20260107/` |

**差距（SFT - Base）**
- acc@1：+0.3146
- Mean@16：+0.3039
- Pass@16：+0.1713

**结论**：在同分布任务（GSM8K→GSM8K）上，SFT 提升非常显著，趋势与论文主张一致（SFT cold-start 对推理表现帮助大）：
- 论文：Parallel-R1（RL）强调“仅 SFT 会模式模仿，RL 更能泛化”，但也承认 cold-start SFT 是关键阶段。见：`file://2509.07980v2.pdf`

### 3.4 GSM8K SFT（5ep）迁移到 MedQA（k=16 采样）

| 模型 | acc@1 | Mean@16 | Pass@16 | final_answer_ratio | 评测目录 |
|---|---:|---:|---:|---:|---|
| GSM8K SFT 5ep (gs230) → MedQA | 0.1956 | 0.1945 | 0.8256 | 0.3724 | `eval_outputs/medqa_sft_gsm8k_5ep_k16_20260107/` |

**结论**：跨域（数学→医学）泛化有限，并且格式遵从性较弱（`final_answer_ratio` 低），不如专门在 MedQA 上做 SFT。

---

## 4. 输出差异示例（MedQA）

示例（同一题 idx=7）观察到的典型差异：
- **Base / GSM8K SFT**：倾向生成较长推理文本，在 `max_new_tokens=64` 限制下更容易被截断，导致未能稳定输出 `Final Answer:` 或预测偏移。
- **MedQA SFT**：极高概率直接输出 `Final Answer: X`，格式更稳定。

对应的逐样本输出文件（可用于抽查）：
- Base：`eval_outputs/medqa_base_k16_20260106/predictions.jsonl`
- MedQA SFT：`eval_outputs/medqa_sft_gs80_k16_20260106/predictions.jsonl`
- GSM8K SFT：`eval_outputs/medqa_sft_gsm8k_5ep_k16_20260107/predictions.jsonl`

---

## 5. RL 训练尝试（GSM8K）与当前状态

### 5.1 目标
- 在 GSM8K 上进行 Parallel-R1 风格 RL 训练（Ray + vLLM rollout），以探索并行思考策略（论文：`file://2509.07980v2.pdf`）。

### 5.2 已做工作
- 编写并多轮调整脚本：`verl/training_scripts/rl_gsm8k_2gpu.sh`
- 能启动 Ray/vLLM，并在部分尝试中产出第 1 步 rollout：`rollout-log/1.jsonl`。

### 5.3 主要问题
- 多次在 vLLM `cumem_allocator` 的 `wake_up(weights)` 触发 **CUDA OOM**，导致训练停在 step=1 后假死（日志有明确 `CUDA Error: out of memory`）。
- 在 2×A100 40GB 条件下，vLLM rollout 的显存峰值非常敏感（尤其是长序列、多路径、多采样并行时）。

### 5.4 当前状态
- 按需求已执行：**停止全部 RL / Ray / vLLM / 评测相关进程**，并确认 GPU1/GPU3 无残留占用。

---

## 6. 建议的下一步（可选）

- 若要稳定跑 RL（Parallel-R1 风格）：
  - 优先建议 **8×80GB（A100/H800）** 或者进一步降低 rollout 复杂度（路径数、生成长度、并行度），或切换 rollout backend（避免 vLLM cumem allocator 峰值）。
- 医学方向（MedQA）：
  - 当前结果显示：**领域内 SFT（哪怕 1 epoch）对格式与性能提升明显**；后续可考虑：
    - 增加 epoch/steps（在不 OOM 的前提下）
    - 引入更强的可验证奖励/检查器（禁忌、剂量、指南一致性）再做 RL


