# Copyright 2026
#
# Convert MedQA (from local zip) to the parquet schema used by Parallel-R1 training.
#
# Output schema matches GSM8K preprocessing:
# - data_source: str
# - prompt: [{"role":"user","content": question_str}]
# - ability: "medical"
# - reward_model: {"style":"rule","ground_truth": <answer_key>}
# - extra_info: {"split":..., "index":..., "question":..., "answer":..., "reward_method":...}
#
# This is a *format converter*. It does NOT synthesize parallel reasoning traces.

from __future__ import annotations

import argparse
import json
import os
import re
import zipfile
from typing import Dict, Iterable, List, Tuple

import datasets
from transformers import AutoTokenizer

from verl.utils.hdfs_io import copy, makedirs


def load_template(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def format_full_prompts(template: str, problem: str, options_text: str) -> str:
    return template.format(Problem=problem, Options=options_text)


def read_jsonl_from_zip(zip_path: str, member: str) -> Iterable[Dict]:
    with zipfile.ZipFile(zip_path) as zf:
        with zf.open(member) as fp:
            for raw in fp:
                line = raw.decode("utf-8").strip()
                if not line:
                    continue
                yield json.loads(line)


def format_options(options: List[Dict[str, str]]) -> str:
    """Format options to text.

    Supports both:
    - dict: {"A": "...", "B": "...", ...}
    - list[dict]: [{"key":"A","value":"..."}, ...]
    """
    lines = []
    if isinstance(options, dict):
        # keep A/B/C/D/E order if possible
        for k in sorted(options.keys()):
            v = options[k]
            kk = str(k).strip()
            vv = str(v).strip()
            if kk:
                lines.append(f"{kk}. {vv}")
        return "\n".join(lines)

    # options: [{"key":"A","value":"..."}, ...]
    if isinstance(options, list):
        for opt in options:
            if not isinstance(opt, dict):
                continue
            k = str(opt.get("key", "")).strip()
            v = str(opt.get("value", "")).strip()
            if not k:
                continue
            lines.append(f"{k}. {v}")
        return "\n".join(lines)

    return ""


def safe_answer_key(example: Dict) -> str:
    # Prefer answer_idx (A/B/C/D/E). Fallback to 'answer' if idx missing.
    ans = example.get("answer_idx", None)
    if ans is None or str(ans).strip() == "":
        ans = example.get("answer", "")
    return str(ans).strip()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip_path", type=str, default="/home/maqiang/workshop/parallel-r1/data/med_qa/data_clean.zip")
    ap.add_argument("--subset", type=str, default="US_4options", choices=["US", "US_4options", "Mainland", "Taiwan"])
    ap.add_argument("--local_dir", type=str, default="./data_preprocess_scripts/data/med_qa/medqa_us_4options_parallel_v1")
    ap.add_argument("--hdfs_dir", type=str, default=None)
    ap.add_argument("--prompt_template", type=str, default="./data_preprocess_scripts/prompts/medical_qa_parallel_thinking_mcq_v1.txt")
    ap.add_argument(
        "--model_source",
        type=str,
        default="/home/maqiang/workshop/parallel-r1/hf_models/Parallel-R1_Qwen3-4B-Base-add-special-token",
        help="Tokenizer/model path or HF id. Use a local path when running offline.",
    )
    ap.add_argument("--max_length", type=int, default=2048)
    ap.add_argument("--reward_approach", type=str, default="choice_accuracy_reward")
    ap.add_argument("--data_source", type=str, default="MedQA-LocalZip")
    args = ap.parse_args()

    zip_path = args.zip_path
    prompt = load_template(args.prompt_template)
    local_files_only = os.environ.get("TRANSFORMERS_OFFLINE", "0") == "1" or os.environ.get("HF_DATASETS_OFFLINE", "0") == "1"
    tokenizer = AutoTokenizer.from_pretrained(args.model_source, local_files_only=local_files_only)

    # Map subset to zip members
    if args.subset == "US":
        members = {
            "train": "data_clean/questions/US/train.jsonl",
            "valid": "data_clean/questions/US/dev.jsonl",
            "test": "data_clean/questions/US/test.jsonl",
        }
    elif args.subset == "US_4options":
        members = {
            "train": "data_clean/questions/US/4_options/phrases_no_exclude_train.jsonl",
            "valid": "data_clean/questions/US/4_options/phrases_no_exclude_dev.jsonl",
            "test": "data_clean/questions/US/4_options/phrases_no_exclude_test.jsonl",
        }
    elif args.subset == "Mainland":
        members = {
            "train": "data_clean/questions/Mainland/train.jsonl",
            "valid": "data_clean/questions/Mainland/dev.jsonl",
            "test": "data_clean/questions/Mainland/test.jsonl",
        }
    else:  # Taiwan
        members = {
            "train": "data_clean/questions/Taiwan/train.jsonl",
            "valid": "data_clean/questions/Taiwan/dev.jsonl",
            "test": "data_clean/questions/Taiwan/test.jsonl",
        }

    os.makedirs(args.local_dir, exist_ok=True)

    def convert_split(split: str) -> datasets.Dataset:
        raw_iter = read_jsonl_from_zip(zip_path, members[split])
        raw_list = list(raw_iter)
        ds = datasets.Dataset.from_list(raw_list)

        def process_fn(example: Dict, idx: int) -> Dict:
            problem = str(example.get("question", "")).strip()
            options = example.get("options", {})
            options_text = format_options(options)
            question = format_full_prompts(prompt, problem, options_text)

            gold = safe_answer_key(example)
            # For SFT target, keep it simple (no synthetic parallel traces)
            answer_raw = f"Final Answer: {gold}"

            # Filter by token length (prompt + answer) like gsm8k_parallel_thinking.py
            tok_len = len(tokenizer(question + "\n" + answer_raw)["input_ids"])
            if tok_len > args.max_length:
                # Mark for filter (datasets.filter can't access idx easily after map)
                return {"__drop__": True}

            return {
                "data_source": args.data_source,
                "prompt": [{"role": "user", "content": question}],
                "ability": "medical",
                "reward_model": {"style": "rule", "ground_truth": gold},
                "extra_info": {
                    "split": split if split != "valid" else "validation",
                    "index": idx,
                    "question": question,
                    "answer": answer_raw,
                    "reward_method": args.reward_approach,
                    # Keep some original fields for debugging
                    "answer_idx": example.get("answer_idx", None),
                    "answer_text": example.get("answer", None),
                    "meta_info": example.get("meta_info", None),
                },
            }

        ds = ds.map(lambda ex, i: process_fn(ex, i), with_indices=True)
        ds = ds.filter(lambda ex: ex.get("__drop__", False) is False)
        # cleanup
        drop_cols = [c for c in ds.column_names if c == "__drop__"]
        if drop_cols:
            ds = ds.remove_columns(drop_cols)
        return ds

    train_ds = convert_split("train")
    valid_ds = convert_split("valid")
    test_ds = convert_split("test")

    train_ds.to_parquet(os.path.join(args.local_dir, "train.parquet"))
    valid_ds.to_parquet(os.path.join(args.local_dir, "valid.parquet"))
    test_ds.to_parquet(os.path.join(args.local_dir, "test.parquet"))

    if args.hdfs_dir is not None:
        makedirs(args.hdfs_dir)
        copy(src=args.local_dir, dst=args.hdfs_dir)

    print(f"[DONE] wrote to {args.local_dir}")
    print(f"train={len(train_ds)} valid={len(valid_ds)} test={len(test_ds)}")


if __name__ == "__main__":
    main()


