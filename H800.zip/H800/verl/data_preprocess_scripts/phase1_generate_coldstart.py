#!/usr/bin/env python3
"""
Phase 1: Cold-Start Data Synthesis (弱监督数据生成)

D-CRPO.pdf 指导：
- 使用 HuatuoGPT-o1-8B 作为 Teacher
- 针对 MedQA 问题生成 3 条具有互斥性的鉴别诊断路径
- 规模：对 MedQA 训练集 (10k+) 进行生成，建议生成 3 个 Pass
- 输出格式：每条输出应包含 <Parallel><Path>...</Path></Parallel> 结构

用法：
    python phase1_generate_coldstart.py \
        --model_path /path/to/HuatuoGPT-o1-8B \
        --medqa_parquet ./data/med_qa/medqa_us_4options_parallel_v1/train.parquet \
        --output_dir ./data/med_qa/coldstart_raw \
        --num_passes 3 \
        --batch_size 4
"""

from __future__ import annotations

import argparse
import json
import os
import time
from typing import Any, Dict, List, Optional

import pandas as pd
import torch
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer


# 诱导 HuatuoGPT 生成鉴别诊断推理的 system prompt
SYSTEM_PROMPT = """You are an expert medical diagnostician. When analyzing a clinical case, you must consider multiple differential diagnoses before reaching a conclusion.

Your response MUST follow this exact format:
1. Start with <Parallel> tag
2. Include exactly 3 independent diagnostic reasoning paths, each wrapped in <Path>...</Path> tags
3. Each path should explore a DIFFERENT possible diagnosis with its supporting evidence
4. Close with </Parallel> tag
5. After </Parallel>, write a <Summary>...</Summary> synthesizing insights from all paths
6. End with "Final Answer: X" where X is the correct option letter (A/B/C/D/E)

Example structure:
<Parallel>
<Path>
Considering diagnosis A: [reasoning with evidence]
</Path>
<Path>
Considering diagnosis B: [reasoning with evidence]
</Path>
<Path>
Considering diagnosis C: [reasoning with evidence]
</Path>
</Parallel>
<Summary>
Based on the differential analysis above, [synthesis and conclusion]
</Summary>
Final Answer: X"""


def build_prompt(question: str) -> List[Dict[str, str]]:
    """构建对话格式的 prompt"""
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": question},
    ]


def extract_question_from_extra_info(extra_info: Any) -> Optional[str]:
    """从 extra_info 字段提取原始问题"""
    if isinstance(extra_info, dict):
        return extra_info.get("question", None)
    if isinstance(extra_info, str):
        try:
            d = json.loads(extra_info)
            return d.get("question", None)
        except Exception:
            return None
    return None


def generate_batch(
    model,
    tokenizer,
    prompts: List[List[Dict[str, str]]],
    max_new_tokens: int = 2048,
    temperature: float = 0.7,
    top_p: float = 0.9,
    do_sample: bool = True,
) -> List[str]:
    """批量生成"""
    # 应用 chat template
    texts = [
        tokenizer.apply_chat_template(p, tokenize=False, add_generation_prompt=True)
        for p in prompts
    ]
    
    inputs = tokenizer(
        texts,
        return_tensors="pt",
        padding=True,
        truncation=True,
        max_length=2048,
    ).to(model.device)
    
    with torch.inference_mode():
        outputs = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            top_p=top_p,
            do_sample=do_sample,
            pad_token_id=tokenizer.eos_token_id,
        )
    
    # 只取新生成的部分
    input_len = inputs["input_ids"].shape[1]
    generated = outputs[:, input_len:]
    
    return tokenizer.batch_decode(generated, skip_special_tokens=True)


def main():
    parser = argparse.ArgumentParser(description="Phase 1: Generate cold-start data using HuatuoGPT")
    parser.add_argument(
        "--model_path",
        type=str,
        default="/home/maqiang/workshop/parallel-r1/hf_models/HuatuoGPT-o1-8B",
        help="Path to HuatuoGPT-o1-8B model",
    )
    parser.add_argument(
        "--medqa_parquet",
        type=str,
        default="/home/maqiang/workshop/parallel-r1/verl/data_preprocess_scripts/data/med_qa/medqa_us_4options_parallel_v1/train.parquet",
        help="Path to MedQA train parquet",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="/home/maqiang/workshop/parallel-r1/verl/data_preprocess_scripts/data/med_qa/coldstart_raw",
        help="Output directory for raw generations",
    )
    parser.add_argument("--num_passes", type=int, default=3, help="Number of generation passes")
    parser.add_argument("--batch_size", type=int, default=2, help="Batch size for generation")
    parser.add_argument("--max_new_tokens", type=int, default=2048, help="Max tokens to generate")
    parser.add_argument("--temperature", type=float, default=0.7, help="Sampling temperature")
    parser.add_argument("--top_p", type=float, default=0.9, help="Top-p sampling")
    parser.add_argument("--limit", type=int, default=0, help="Limit number of samples (0=all)")
    parser.add_argument("--start_idx", type=int, default=0, help="Start index (for sharding/resume)")
    parser.add_argument(
        "--pass_ids",
        type=str,
        default="",
        help="Comma-separated pass ids to run (e.g. '2' to only run pass_2). Empty means run 0..num_passes-1",
    )
    parser.add_argument(
        "--min_index",
        type=int,
        default=None,
        help="Filter by extra_info.index >= min_index (uses row extra_info.index if present).",
    )
    parser.add_argument(
        "--max_index",
        type=int,
        default=None,
        help="Filter by extra_info.index < max_index (uses row extra_info.index if present).",
    )
    parser.add_argument(
        "--skip_index_files",
        type=str,
        default="",
        help="Comma-separated jsonl files whose 'index' fields will be skipped (avoid regenerating existing records).",
    )
    parser.add_argument(
        "--only_indices_file",
        type=str,
        default="",
        help="Optional: a txt/jsonl file specifying which indices to generate (one int per line, or jsonl with {index:...}).",
    )
    parser.add_argument("--seed", type=int, default=42, help="Global seed for reproducibility")
    parser.add_argument("--device", type=str, default="auto", help="Device for model")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    print(f"[INFO] Loading MedQA data from {args.medqa_parquet}")
    df = pd.read_parquet(args.medqa_parquet)

    # Compute a stable per-row index (prefer extra_info.index)
    def _row_index_from_extra(extra_info, fallback):
        if isinstance(extra_info, dict) and "index" in extra_info:
            return int(extra_info["index"])
        return int(fallback)

    if "extra_info" in df:
        extras = df["extra_info"].tolist()
        row_indices = [_row_index_from_extra(extras[i], i) for i in range(len(extras))]
    else:
        row_indices = list(range(len(df)))
    df = df.copy()
    df["_row_index"] = row_indices

    # Optional filters
    if args.min_index is not None:
        df = df[df["_row_index"] >= int(args.min_index)]
    if args.max_index is not None:
        df = df[df["_row_index"] < int(args.max_index)]

    # Optional explicit index allow-list
    if args.only_indices_file.strip():
        allow = set()
        path = args.only_indices_file.strip()
        if not os.path.exists(path):
            raise FileNotFoundError(f"only_indices_file not found: {path}")
        if path.endswith(".jsonl"):
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                    except Exception:
                        continue
                    idx = rec.get("index", None)
                    if isinstance(idx, int):
                        allow.add(idx)
        else:
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        allow.add(int(line))
                    except Exception:
                        continue
        before = len(df)
        df = df[df["_row_index"].isin(sorted(allow))]
        print(f"[INFO] Applied only_indices_file={path}: {before} -> {len(df)}")

    # Optional positional slicing (legacy / convenience)
    if args.start_idx > 0:
        df = df.iloc[args.start_idx:]
    if args.limit > 0:
        df = df.iloc[: args.limit]

    print(
        f"[INFO] Loaded {len(df)} samples (start_idx={args.start_idx}, limit={args.limit}, "
        f"min_index={args.min_index}, max_index={args.max_index})"
    )

    print(f"[INFO] Loading model from {args.model_path}")
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        torch_dtype=torch.bfloat16,
        device_map=args.device,
        trust_remote_code=True,
    )
    tokenizer = AutoTokenizer.from_pretrained(args.model_path, trust_remote_code=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token_id = tokenizer.eos_token_id
    tokenizer.padding_side = "left"
    model.eval()
    # set seed
    try:
        torch.manual_seed(args.seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(args.seed)
    except Exception:
        pass

    if args.pass_ids.strip():
        pass_ids = [int(x) for x in args.pass_ids.split(",") if x.strip() != ""]
    else:
        pass_ids = list(range(args.num_passes))

    for pass_id in pass_ids:
        output_file = os.path.join(args.output_dir, f"pass_{pass_id}.jsonl")
        print(f"\n[INFO] === Pass {pass_id} ===")
        print(f"[INFO] Output: {output_file}")

        # 支持断点续跑：检查已有输出
        existing_indices = set()
        if os.path.exists(output_file):
            with open(output_file, "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        rec = json.loads(line)
                        existing_indices.add(rec.get("index", -1))
                    except Exception:
                        pass
            print(f"[INFO] Found {len(existing_indices)} existing records, will skip them")

        # Also skip indices from external files (e.g., previous partial pass_2.jsonl)
        if args.skip_index_files.strip():
            for path in [p.strip() for p in args.skip_index_files.split(",") if p.strip()]:
                if not os.path.exists(path):
                    print(f"[WARN] skip_index_file not found: {path}")
                    continue
                cnt = 0
                with open(path, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            rec = json.loads(line)
                            idx = rec.get("index", None)
                            if idx is not None:
                                existing_indices.add(idx)
                                cnt += 1
                        except Exception:
                            continue
                print(f"[INFO] Loaded {cnt} skip indices from {path}")

        start_time = time.time()
        with open(output_file, "a", encoding="utf-8") as fo:
            indices = list(df.index)
            for batch_start in tqdm(range(0, len(indices), args.batch_size), desc=f"Pass {pass_id}"):
                batch_indices = indices[batch_start : batch_start + args.batch_size]
                
                # 过滤已处理的
                batch_to_process = []
                for idx in batch_indices:
                    row = df.loc[idx]
                    row_index = int(row.get("_row_index", idx))
                    if row_index in existing_indices:
                        continue
                    batch_to_process.append((idx, row, row_index))
                
                if not batch_to_process:
                    continue

                # 构建 prompts
                prompts = []
                metas = []
                for idx, row, row_index in batch_to_process:
                    extra_info = row.get("extra_info", {})
                    question = extract_question_from_extra_info(extra_info)
                    if question is None:
                        question = row.get("question", "")
                    
                    # 获取 ground truth
                    rm = row.get("reward_model", {})
                    gt = rm.get("ground_truth", "") if isinstance(rm, dict) else ""
                    
                    prompts.append(build_prompt(question))
                    metas.append({
                        "index": row_index,
                        "ground_truth": gt,
                        "question": question,
                        "pass_id": pass_id,
                    })

                if not prompts:
                    continue

                # 生成
                try:
                    outputs = generate_batch(
                        model,
                        tokenizer,
                        prompts,
                        max_new_tokens=args.max_new_tokens,
                        temperature=args.temperature,
                        top_p=args.top_p,
                    )
                except Exception as e:
                    print(f"[ERROR] Generation failed: {e}")
                    continue

                # 保存
                for meta, output in zip(metas, outputs):
                    record = {
                        **meta,
                        "response": output,
                        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                    }
                    fo.write(json.dumps(record, ensure_ascii=False) + "\n")
                fo.flush()

        elapsed = time.time() - start_time
        print(f"[INFO] Pass {pass_id} done in {elapsed:.1f}s")

    print("\n[DONE] All passes completed!")
    print(f"[DONE] Raw outputs saved to {args.output_dir}/pass_*.jsonl")
    print("[NEXT] Run phase1_clean_coldstart.py to filter and create SFT parquet")


if __name__ == "__main__":
    main()

