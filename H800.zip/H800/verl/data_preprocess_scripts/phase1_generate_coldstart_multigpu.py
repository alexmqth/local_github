#!/usr/bin/env python3
"""
Phase 1 Cold-Start Data Synthesis (Multi-GPU, Single File)

目标：在单机多卡（例如 8×H800）上并行生成 MedQA cold-start 数据：
- Teacher: HuatuoGPT-o1-8B（本地 HF checkpoint）
- 数据：MedQA v2 parquet（extra_info.question 含完整选项 A/B/C/D）
- 生成：每题生成 3 个 pass（pass_0/1/2），每个 pass 输出包含 <Parallel>/<Path>/<Summary> 与 Final Answer
- 断点续跑：每个 shard 的每个 pass 都会跳过已存在的 index，避免重复生成

使用方式（推荐在 8×H800）：
  python phase1_generate_coldstart_multigpu.py \\
    --mode orchestrate \\
    --num_gpus 8 \\
    --model_path /path/to/HuatuoGPT-o1-8B \\
    --medqa_parquet /path/to/medqa_us_4options_parallel_v2/train.parquet \\
    --output_dir /path/to/coldstart_raw_v2_huatuo \\
    --num_passes 3 \\
    --batch_size 4 \\
    --max_new_tokens 1024 \\
    --seed 42

输出结构：
  output_dir/
    shard0/pass_0.jsonl
    shard0/pass_1.jsonl
    shard0/pass_2.jsonl
    ...
    shard7/pass_2.jsonl

备注：
- 本脚本是“单文件版本”：既包含 orchestrator，也包含 worker 逻辑。
- 生成结束后，用 phase1_clean_coldstart.py 对 output_dir 做清洗即可。
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
import torch
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer


SYSTEM_PROMPT = """You are an expert medical diagnostician. When analyzing a clinical case, you must consider multiple differential diagnoses before reaching a conclusion.

Your response MUST follow this exact format:
1. Start with <Parallel> tag
2. Include exactly 3 independent diagnostic reasoning paths, each wrapped in <Path>...</Path> tags
3. Each path should explore a DIFFERENT possible diagnosis with its supporting evidence
4. Close with </Parallel> tag
5. After </Parallel>, write a <Summary>...</Summary> synthesizing insights from all paths
6. End with "Final Answer: X" where X is the correct option letter (A/B/C/D/E)

Do NOT use markdown headings (e.g., "## Thinking"). Put your reasoning ONLY inside the tags above.
"""


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


def build_prompt(question: str) -> List[Dict[str, str]]:
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": question},
    ]


def extract_question_from_extra_info(extra_info: Any) -> Optional[str]:
    if isinstance(extra_info, dict):
        return extra_info.get("question", None)
    if isinstance(extra_info, str):
        try:
            d = json.loads(extra_info)
            return d.get("question", None)
        except Exception:
            return None
    return None


def get_row_index(row: pd.Series, fallback: int) -> int:
    extra_info = row.get("extra_info", None)
    if isinstance(extra_info, dict) and "index" in extra_info:
        try:
            return int(extra_info["index"])
        except Exception:
            pass
    return int(fallback)


def iter_existing_indices(path: str) -> set[int]:
    indices: set[int] = set()
    if not os.path.exists(path):
        return indices
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except Exception:
                continue
            idx = r.get("index", None)
            if isinstance(idx, int):
                indices.add(idx)
    return indices


@torch.no_grad()
def generate_batch(
    model,
    tokenizer,
    prompts: List[List[Dict[str, str]]],
    max_input_length: int,
    max_new_tokens: int,
    temperature: float,
    top_p: float,
    do_sample: bool = True,
) -> List[str]:
    texts = [tokenizer.apply_chat_template(p, tokenize=False, add_generation_prompt=True) for p in prompts]
    inputs = tokenizer(
        texts,
        return_tensors="pt",
        padding=True,
        truncation=True,
        max_length=max_input_length,
    ).to(model.device)

    outputs = model.generate(
        **inputs,
        max_new_tokens=max_new_tokens,
        temperature=temperature,
        top_p=top_p,
        do_sample=do_sample,
        pad_token_id=tokenizer.eos_token_id,
    )
    input_len = inputs["input_ids"].shape[1]  # padded prompt length
    gen = outputs[:, input_len:]
    return tokenizer.batch_decode(gen, skip_special_tokens=True)


@dataclass
class WorkerConfig:
    worker_id: int
    world_size: int
    model_path: str
    medqa_parquet: str
    output_dir: str
    num_passes: int
    pass_ids: List[int]
    seed: int
    batch_size: int
    max_input_length: int
    max_new_tokens: int
    temperature: float
    top_p: float
    min_index: int
    max_index: int
    trust_remote_code: bool


def run_worker(cfg: WorkerConfig) -> None:
    os.makedirs(cfg.output_dir, exist_ok=True)
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

    # Each worker sees only one GPU via CUDA_VISIBLE_DEVICES set by orchestrator.
    # Still, set seed deterministically per pass.
    print(f"[{_now()}][worker{cfg.worker_id}] loading data...", flush=True)
    df = pd.read_parquet(cfg.medqa_parquet)
    # Add stable row index and filter to shard range
    df = df.copy()
    df["_row_index"] = [get_row_index(df.iloc[i], i) for i in range(len(df))]
    df = df[(df["_row_index"] >= cfg.min_index) & (df["_row_index"] < cfg.max_index)]
    df = df.sort_values("_row_index")
    print(
        f"[{_now()}][worker{cfg.worker_id}] shard range [{cfg.min_index},{cfg.max_index}) rows={len(df)}",
        flush=True,
    )

    print(f"[{_now()}][worker{cfg.worker_id}] loading model: {cfg.model_path}", flush=True)
    model = AutoModelForCausalLM.from_pretrained(
        cfg.model_path,
        torch_dtype=torch.bfloat16,
        device_map="cuda",  # rely on single visible GPU
        trust_remote_code=cfg.trust_remote_code,
    )
    tokenizer = AutoTokenizer.from_pretrained(cfg.model_path, trust_remote_code=cfg.trust_remote_code)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token_id = tokenizer.eos_token_id
    tokenizer.padding_side = "left"
    model.eval()

    # Pre-extract (index, question, gt) for speed
    items: List[Tuple[int, str, str]] = []
    for _, row in df.iterrows():
        ridx = int(row["_row_index"])
        q = extract_question_from_extra_info(row.get("extra_info", {})) or str(row.get("question", ""))
        rm = row.get("reward_model", {})
        gt = rm.get("ground_truth", "") if isinstance(rm, dict) else ""
        items.append((ridx, q, str(gt).strip().upper()))

    for pass_id in cfg.pass_ids:
        # deterministic but different per pass
        seed = int(cfg.seed) + int(pass_id)
        try:
            torch.manual_seed(seed)
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(seed)
        except Exception:
            pass

        out_path = os.path.join(cfg.output_dir, f"pass_{pass_id}.jsonl")
        existing = iter_existing_indices(out_path)
        if existing:
            print(
                f"[{_now()}][worker{cfg.worker_id}] pass{pass_id}: found {len(existing)} existing indices, skip.",
                flush=True,
            )

        to_run = [(idx, q, gt) for (idx, q, gt) in items if idx not in existing]
        print(f"[{_now()}][worker{cfg.worker_id}] pass{pass_id}: to_generate={len(to_run)}", flush=True)

        start = time.time()
        with open(out_path, "a", encoding="utf-8") as fo:
            for off in tqdm(range(0, len(to_run), cfg.batch_size), desc=f"worker{cfg.worker_id}/pass{pass_id}"):
                batch = to_run[off : off + cfg.batch_size]
                prompts = [build_prompt(q) for (_, q, _) in batch]
                outs = generate_batch(
                    model=model,
                    tokenizer=tokenizer,
                    prompts=prompts,
                    max_input_length=cfg.max_input_length,
                    max_new_tokens=cfg.max_new_tokens,
                    temperature=cfg.temperature,
                    top_p=cfg.top_p,
                    do_sample=True,
                )
                for (idx, q, gt), out in zip(batch, outs, strict=True):
                    rec = {
                        "index": int(idx),
                        "pass_id": int(pass_id),
                        "worker_id": int(cfg.worker_id),
                        "ground_truth": gt,
                        "question": q,
                        "response": out,
                        "timestamp": _now(),
                        "seed": int(seed),
                    }
                    fo.write(json.dumps(rec, ensure_ascii=False) + "\n")
                fo.flush()

        print(
            f"[{_now()}][worker{cfg.worker_id}] pass{pass_id} done in {time.time()-start:.1f}s, wrote {out_path}",
            flush=True,
        )


def split_ranges(n: int, k: int) -> List[Tuple[int, int]]:
    """Split [0,n) into k contiguous ranges."""
    out = []
    for i in range(k):
        a = (i * n) // k
        b = ((i + 1) * n) // k
        out.append((a, b))
    return out


def run_orchestrator(args) -> None:
    os.makedirs(args.output_dir, exist_ok=True)
    os.makedirs(args.log_dir, exist_ok=True)

    df = pd.read_parquet(args.medqa_parquet)
    n = len(df)
    ranges = split_ranges(n, len(args.gpus))
    print(f"[orchestrate] dataset size={n}, num_gpus={len(args.gpus)}", flush=True)
    for rid, (a, b) in enumerate(ranges):
        print(f"[orchestrate] shard{rid}: [{a},{b}) on gpu {args.gpus[rid]}", flush=True)

    pass_ids = args.pass_ids if args.pass_ids else list(range(args.num_passes))
    procs = []
    script = os.path.abspath(__file__)

    for worker_id, gpu in enumerate(args.gpus):
        shard_out = os.path.join(args.output_dir, f"shard{worker_id}")
        os.makedirs(shard_out, exist_ok=True)
        log_path = os.path.join(args.log_dir, f"phase1_worker{worker_id}.log")
        a, b = ranges[worker_id]

        cmd = [
            sys.executable,
            script,
            "--mode",
            "worker",
            "--worker_id",
            str(worker_id),
            "--world_size",
            str(len(args.gpus)),
            "--model_path",
            args.model_path,
            "--medqa_parquet",
            args.medqa_parquet,
            "--output_dir",
            shard_out,
            "--num_passes",
            str(args.num_passes),
            "--pass_ids",
            ",".join(str(x) for x in pass_ids),
            "--seed",
            str(args.seed),
            "--batch_size",
            str(args.batch_size),
            "--max_input_length",
            str(args.max_input_length),
            "--max_new_tokens",
            str(args.max_new_tokens),
            "--temperature",
            str(args.temperature),
            "--top_p",
            str(args.top_p),
            "--min_index",
            str(a),
            "--max_index",
            str(b),
        ]
        if args.trust_remote_code:
            cmd.append("--trust_remote_code")

        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = str(gpu)

        print(f"[orchestrate] launch worker{worker_id} on gpu={gpu}, log={log_path}", flush=True)
        lf = open(log_path, "w", encoding="utf-8")
        p = subprocess.Popen(cmd, stdout=lf, stderr=lf, env=env)
        procs.append((p, lf, log_path))

    # wait
    failed = []
    for p, lf, log_path in procs:
        rc = p.wait()
        lf.close()
        if rc != 0:
            failed.append((log_path, rc))

    if failed:
        print("[orchestrate] Some workers failed:", flush=True)
        for log_path, rc in failed:
            print(f"  - {log_path}: exit_code={rc}", flush=True)
        raise SystemExit(1)

    print("[orchestrate] All workers completed successfully.", flush=True)


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["orchestrate", "worker"], default="orchestrate")

    # common
    ap.add_argument("--model_path", type=str, required=True)
    ap.add_argument("--medqa_parquet", type=str, required=True)
    ap.add_argument("--output_dir", type=str, required=True)
    ap.add_argument("--num_passes", type=int, default=3)
    ap.add_argument("--pass_ids", type=str, default="", help="comma-separated pass ids, empty means 0..num_passes-1")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--batch_size", type=int, default=4)
    ap.add_argument("--max_input_length", type=int, default=2048)
    ap.add_argument("--max_new_tokens", type=int, default=1024)
    ap.add_argument("--temperature", type=float, default=0.7)
    ap.add_argument("--top_p", type=float, default=0.9)
    ap.add_argument("--trust_remote_code", action="store_true", default=True)

    # orchestrator
    ap.add_argument("--num_gpus", type=int, default=8)
    ap.add_argument("--gpus", type=str, default="", help="comma-separated gpu ids, default=0..num_gpus-1")
    ap.add_argument("--log_dir", type=str, default="./logs/phase1_coldstart_multigpu")

    # worker
    ap.add_argument("--worker_id", type=int, default=0)
    ap.add_argument("--world_size", type=int, default=1)
    ap.add_argument("--min_index", type=int, default=0)
    ap.add_argument("--max_index", type=int, default=0)

    args = ap.parse_args()

    if args.mode == "orchestrate":
        if args.gpus.strip():
            args.gpus = [int(x) for x in args.gpus.split(",") if x.strip() != ""]
        else:
            args.gpus = list(range(args.num_gpus))
    else:
        args.gpus = []

    if args.pass_ids.strip():
        args.pass_ids = [int(x) for x in args.pass_ids.split(",") if x.strip() != ""]
    else:
        args.pass_ids = []

    return args


def main():
    args = parse_args()
    if args.mode == "orchestrate":
        run_orchestrator(args)
        return

    cfg = WorkerConfig(
        worker_id=args.worker_id,
        world_size=args.world_size,
        model_path=args.model_path,
        medqa_parquet=args.medqa_parquet,
        output_dir=args.output_dir,
        num_passes=args.num_passes,
        pass_ids=args.pass_ids if args.pass_ids else list(range(args.num_passes)),
        seed=args.seed,
        batch_size=args.batch_size,
        max_input_length=args.max_input_length,
        max_new_tokens=args.max_new_tokens,
        temperature=args.temperature,
        top_p=args.top_p,
        min_index=args.min_index,
        max_index=args.max_index,
        trust_remote_code=args.trust_remote_code,
    )
    run_worker(cfg)


if __name__ == "__main__":
    main()


