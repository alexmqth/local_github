#!/usr/bin/env python3
"""
DDXPlus evaluation: Differential Diagnosis Coverage (DDC).

DDC definition (per sample):
  DDC = (# unique diseases from ground-truth DIFFERENTIAL_DIAGNOSIS that appear in model output) / (# gt diseases)

This is a lightweight string-match approximation to validate that generated differential diagnoses
cover clinically meaningful candidates (as suggested in D-CRPO.pdf).
"""

from __future__ import annotations

import argparse
import ast
import json
import os
import re
import time
from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Tuple

import pandas as pd
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


def _now_ts() -> str:
    return time.strftime("%Y%m%d_%H%M%S", time.localtime())


def _ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def _parse_ddx_list(s: str) -> List[str]:
    # s like: "[['Bronchitis', 0.19], ['Pneumonia', 0.17], ...]"
    try:
        data = ast.literal_eval(s)
    except Exception:
        return []
    out = []
    for item in data:
        if isinstance(item, (list, tuple)) and len(item) >= 1:
            out.append(str(item[0]))
    return out


def build_prompt(age: Any, sex: Any, evidences: str, initial: str) -> str:
    return (
        "You are a clinician. Given the patient info, produce a differential diagnosis list.\n"
        "Output requirements:\n"
        "- Provide 5-10 candidate diseases.\n"
        "- Prefer names (not codes).\n"
        "- End with a line 'Final Answer: <most likely disease name>'.\n\n"
        f"Patient:\n- Age: {age}\n- Sex: {sex}\n- Initial evidence: {initial}\n- Evidences: {evidences}\n\n"
    )


def calc_ddc(output_text: str, gt_diseases: List[str]) -> Tuple[float, List[str]]:
    if not gt_diseases:
        return 0.0, []
    text = (output_text or "").lower()
    matched = []
    for d in gt_diseases:
        d_norm = d.lower().strip()
        if not d_norm:
            continue
        # word-boundary-ish matching (still robust for parentheses)
        pat = re.escape(d_norm)
        if re.search(pat, text):
            matched.append(d)
    matched = sorted(set(matched))
    return len(matched) / max(1, len(set(gt_diseases))), matched


@dataclass
class EvalConfig:
    model_path: str
    ddxplus_csv: str
    out_dir: str
    limit: int
    batch_size: int
    max_new_tokens: int
    seed: int
    cuda_visible_devices: str


@dataclass
class EvalSummary:
    timestamp: str
    model_path: str
    ddxplus_csv: str
    limit: int
    batch_size: int
    max_new_tokens: int
    num_total: int
    ddc_mean: float
    seconds: float


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model_path", required=True)
    ap.add_argument("--ddxplus_csv", required=True, help="e.g. data/ddxplus/test.csv")
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--batch_size", type=int, default=2)
    ap.add_argument("--max_new_tokens", type=int, default=256)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    cfg = EvalConfig(
        model_path=args.model_path,
        ddxplus_csv=args.ddxplus_csv,
        out_dir=args.out_dir,
        limit=int(args.limit),
        batch_size=int(args.batch_size),
        max_new_tokens=int(args.max_new_tokens),
        seed=int(args.seed),
        cuda_visible_devices=os.environ.get("CUDA_VISIBLE_DEVICES", ""),
    )
    _ensure_dir(cfg.out_dir)

    with open(os.path.join(cfg.out_dir, "config.json"), "w", encoding="utf-8") as f:
        json.dump(asdict(cfg), f, ensure_ascii=False, indent=2)

    df = pd.read_csv(cfg.ddxplus_csv)
    if cfg.limit and cfg.limit > 0:
        df = df.iloc[: cfg.limit].copy()

    print(f"[INFO] Loading model from {cfg.model_path}", flush=True)
    model = AutoModelForCausalLM.from_pretrained(cfg.model_path, torch_dtype=torch.bfloat16, device_map="auto")
    tok = AutoTokenizer.from_pretrained(cfg.model_path)
    tok.padding_side = "left"
    if tok.pad_token_id is None and tok.eos_token_id is not None:
        tok.pad_token_id = tok.eos_token_id
    model.eval()

    if cfg.seed:
        try:
            torch.manual_seed(cfg.seed)
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(cfg.seed)
        except Exception:
            pass

    out_jsonl = os.path.join(cfg.out_dir, "predictions.jsonl")
    start = time.time()
    ddc_sum = 0.0
    n = 0

    with open(out_jsonl, "w", encoding="utf-8") as fo:
        idxs = list(df.index)
        for off in range(0, len(idxs), cfg.batch_size):
            batch_idxs = idxs[off : off + cfg.batch_size]
            prompts: List[str] = []
            gts: List[List[str]] = []
            metas: List[Dict[str, Any]] = []
            for idx in batch_idxs:
                row = df.loc[idx]
                gt = _parse_ddx_list(str(row.get("DIFFERENTIAL_DIAGNOSIS", "")))
                prompts.append(
                    build_prompt(
                        age=row.get("AGE", ""),
                        sex=row.get("SEX", ""),
                        evidences=str(row.get("EVIDENCES", "")),
                        initial=str(row.get("INITIAL_EVIDENCE", "")),
                    )
                )
                gts.append(gt)
                metas.append(
                    {
                        "PATHOLOGY": row.get("PATHOLOGY", ""),
                        "AGE": row.get("AGE", ""),
                        "SEX": row.get("SEX", ""),
                    }
                )

            inputs = tok(prompts, return_tensors="pt", padding=True, truncation=True).to(model.device)
            with torch.inference_mode():
                out = model.generate(
                    **inputs,
                    max_new_tokens=cfg.max_new_tokens,
                    do_sample=False,
                    pad_token_id=tok.eos_token_id,
                )
            texts = tok.batch_decode(out, skip_special_tokens=True)

            for idx, prompt, text, gt, meta in zip(batch_idxs, prompts, texts, gts, metas, strict=True):
                ddc, matched = calc_ddc(text, gt)
                ddc_sum += ddc
                n += 1
                rec = {
                    "idx": int(idx),
                    "meta": meta,
                    "ddc": float(ddc),
                    "matched": matched,
                    "gt_size": len(set(gt)),
                    "output": text,
                    "prompt": prompt,
                }
                fo.write(json.dumps(rec, ensure_ascii=False) + "\n")
            fo.flush()

    seconds = time.time() - start
    summary = EvalSummary(
        timestamp=_now_ts(),
        model_path=cfg.model_path,
        ddxplus_csv=cfg.ddxplus_csv,
        limit=cfg.limit,
        batch_size=cfg.batch_size,
        max_new_tokens=cfg.max_new_tokens,
        num_total=n,
        ddc_mean=float(ddc_sum / max(1, n)),
        seconds=float(seconds),
    )
    with open(os.path.join(cfg.out_dir, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(asdict(summary), f, ensure_ascii=False, indent=2)

    print(f"[DONE] DDC={summary.ddc_mean:.4f} over {summary.num_total} samples", flush=True)


if __name__ == "__main__":
    main()


