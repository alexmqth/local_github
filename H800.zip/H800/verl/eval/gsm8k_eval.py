#!/usr/bin/env python3
"""
GSM8K-style accuracy evaluation for Parallel-R1 checkpoints.

Supports:
- Greedy generation (do_sample=False) for acc@1
- Multi-sampling (do_sample=True, num_samples=k) for Mean@k / Pass@k

Example:
  # Greedy (acc@1)
  python eval/gsm8k_eval.py --model_path ... --data_parquet ... --out_dir ...

  # k=16 sampling (Mean@16 / Pass@16)
  python eval/gsm8k_eval.py --model_path ... --data_parquet ... --out_dir ... \
    --num_samples 16 --do_sample --temperature 1.0 --top_p 1.0 --top_k 0
"""

from __future__ import annotations

import argparse
import json
import os
import re
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


_NUM_RE = re.compile(r"[-+]?\d+(?:,\d{3})*(?:\.\d+)?")
_PARALLEL_TAG_RE = re.compile(r"<Parallel>|</Parallel>|<Path>|</Path>|<Summary>|</Summary>", re.IGNORECASE)


def _now_ts() -> str:
    return time.strftime("%Y%m%d_%H%M%S", time.localtime())


def _ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def _extract_problem(question_blob: str) -> str:
    """
    Input is the training-style question that contains lots of instruction text.
    We extract the actual GSM8K problem after the last 'Problem:' occurrence.
    """
    if not question_blob:
        return ""
    idx = question_blob.rfind("Problem:")
    if idx == -1:
        return question_blob.strip()
    return question_blob[idx + len("Problem:") :].strip()


def _normalize_number(s: str) -> str:
    s = s.strip()
    # Remove thousands separators
    s = s.replace(",", "")
    # Normalize +0 / -0
    if s in {"+0", "-0"}:
        return "0"
    # Strip trailing .0
    if re.fullmatch(r"[-+]?\d+\.0+", s):
        s = s.split(".", 1)[0]
    return s


def _extract_pred_number(text: str) -> Optional[str]:
    """
    Priority:
    1) 'Final Answer: <num>'
    2) '#### <num>'
    3) last number in the output
    """
    if not text:
        return None

    m = re.search(r"Final Answer:\s*([-+]?\d+(?:,\d{3})*(?:\.\d+)?)", text, flags=re.IGNORECASE)
    if m:
        return _normalize_number(m.group(1))

    m = re.search(r"####\s*([-+]?\d+(?:,\d{3})*(?:\.\d+)?)", text)
    if m:
        return _normalize_number(m.group(1))

    ms = list(_NUM_RE.finditer(text))
    if ms:
        return _normalize_number(ms[-1].group(0))

    return None


def _has_final_answer(text: str) -> bool:
    """Check if output contains 'Final Answer:' or '####'."""
    if not text:
        return False
    return bool(re.search(r"Final Answer:|####", text, flags=re.IGNORECASE))


def _has_parallel_tags(text: str) -> bool:
    """Check if output contains any <Parallel>/<Path>/<Summary> tags."""
    if not text:
        return False
    return bool(_PARALLEL_TAG_RE.search(text))


def _get_gold(row: pd.Series) -> Optional[str]:
    rm = row.get("reward_model", None)
    if isinstance(rm, dict) and "ground_truth" in rm:
        return _normalize_number(str(rm["ground_truth"]))
    return None


def _get_question(row: pd.Series) -> str:
    extra = row.get("extra_info", None)
    if isinstance(extra, dict) and "question" in extra:
        return str(extra["question"])
    # fallback to prompt if needed
    prompt = row.get("prompt", "")
    if isinstance(prompt, str):
        return prompt
    return str(prompt)


def build_prompt(problem_text: str) -> str:
    # Minimal, evaluation-friendly prompt. We don't require <Parallel> formatting here.
    return (
        "Solve the following problem. "
        "Return ONLY the final numeric answer in the format: Final Answer: <number>\n\n"
        f"{problem_text}\n"
    )


@dataclass
class EvalConfig:
    model_path: str
    data_parquet: str
    out_dir: str
    limit: int
    batch_size: int
    max_new_tokens: int
    num_samples: int
    do_sample: bool
    temperature: float
    top_p: float
    top_k: int
    cuda_visible_devices: str


@dataclass
class EvalSummary:
    timestamp: str
    model_path: str
    data_parquet: str
    limit: int
    batch_size: int
    max_new_tokens: int
    num_samples: int
    do_sample: bool
    temperature: float
    top_p: float
    top_k: int
    num_total: int
    num_correct: int
    accuracy: float
    mean_at_k: float
    pass_at_k: float
    parsed_ratio: float
    final_answer_ratio: float
    parallel_ratio: float
    seconds: float


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model_path", required=True)
    ap.add_argument("--data_parquet", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--limit", type=int, default=0, help="0 means full dataset")
    ap.add_argument("--batch_size", type=int, default=4)
    ap.add_argument("--max_new_tokens", type=int, default=128)
    ap.add_argument("--num_samples", type=int, default=1, help="Number of samples per question (k for Mean@k/Pass@k)")
    ap.add_argument("--do_sample", action="store_true", help="Enable sampling (required for num_samples > 1)")
    ap.add_argument("--temperature", type=float, default=1.0)
    ap.add_argument("--top_p", type=float, default=1.0)
    ap.add_argument("--top_k", type=int, default=0, help="0 means disabled")
    args = ap.parse_args()

    cfg = EvalConfig(
        model_path=args.model_path,
        data_parquet=args.data_parquet,
        out_dir=args.out_dir,
        limit=args.limit,
        batch_size=args.batch_size,
        max_new_tokens=args.max_new_tokens,
        num_samples=args.num_samples,
        do_sample=args.do_sample,
        temperature=args.temperature,
        top_p=args.top_p,
        top_k=args.top_k,
        cuda_visible_devices=os.environ.get("CUDA_VISIBLE_DEVICES", ""),
    )

    _ensure_dir(cfg.out_dir)
    out_jsonl = os.path.join(cfg.out_dir, "predictions.jsonl")
    out_summary = os.path.join(cfg.out_dir, "summary.json")
    out_config = os.path.join(cfg.out_dir, "config.json")

    with open(out_config, "w", encoding="utf-8") as f:
        json.dump(asdict(cfg), f, ensure_ascii=False, indent=2)

    df = pd.read_parquet(cfg.data_parquet)
    if cfg.limit and cfg.limit > 0:
        df = df.iloc[: cfg.limit].copy()

    # Load model/tokenizer
    print(f"[INFO] Loading model from {cfg.model_path}", flush=True)
    model = AutoModelForCausalLM.from_pretrained(
        cfg.model_path, torch_dtype=torch.bfloat16, device_map="auto"
    )
    # Some tokenizers may support this flag; ignore if not.
    try:
        tok = AutoTokenizer.from_pretrained(cfg.model_path, fix_mistral_regex=True)
    except TypeError:
        tok = AutoTokenizer.from_pretrained(cfg.model_path)
    # Decoder-only generation with batching should use left padding to avoid mis-generation.
    tok.padding_side = "left"
    if tok.pad_token_id is None and tok.eos_token_id is not None:
        tok.pad_token_id = tok.eos_token_id

    model.eval()

    start = time.time()
    num_correct = 0  # acc@1 (first sample correct)
    num_total = 0
    total_correct_samples = 0  # for mean@k
    total_samples = 0
    total_passed = 0  # for pass@k (at least one correct per question)
    total_parsed = 0
    total_final_answer = 0
    total_parallel = 0

    k = cfg.num_samples

    # Stream output file to avoid losing progress
    with open(out_jsonl, "w", encoding="utf-8") as fo:
        # batching
        rows = list(df.itertuples(index=True))
        for off in range(0, len(rows), cfg.batch_size):
            batch = rows[off : off + cfg.batch_size]
            prompts: List[str] = []
            meta: List[Tuple[int, str]] = []
            golds: List[Optional[str]] = []

            for r in batch:
                row = df.loc[r.Index]
                q_blob = _get_question(row)
                problem = _extract_problem(q_blob)
                prompt = build_prompt(problem)
                prompts.append(prompt)
                meta.append((int(r.Index), problem))
                golds.append(_get_gold(row))

            # Generate k samples per prompt
            all_texts: List[List[str]] = []  # [batch_size][k]
            
            for _ in range(k):
                inputs = tok(prompts, return_tensors="pt", padding=True, truncation=True).to(model.device)
                with torch.inference_mode():
                    gen_kwargs = {
                        "max_new_tokens": cfg.max_new_tokens,
                        "pad_token_id": tok.eos_token_id,
                    }
                    if cfg.do_sample:
                        gen_kwargs.update({
                            "do_sample": True,
                            "temperature": cfg.temperature,
                            "top_p": cfg.top_p,
                        })
                        if cfg.top_k > 0:
                            gen_kwargs["top_k"] = cfg.top_k
                    else:
                        gen_kwargs["do_sample"] = False
                    
                    out = model.generate(**inputs, **gen_kwargs)
                texts = tok.batch_decode(out, skip_special_tokens=True)
                
                if not all_texts:
                    all_texts = [[] for _ in range(len(texts))]
                for i, t in enumerate(texts):
                    all_texts[i].append(t)

            # Process results
            for (idx, problem), gold, sample_texts in zip(meta, golds, all_texts):
                sample_results = []
                correct_count = 0
                
                for sample_idx, text in enumerate(sample_texts):
                    pred = _extract_pred_number(text)
                    ok = bool(pred is not None and gold is not None and pred == gold)
                    parsed = pred is not None
                    has_fa = _has_final_answer(text)
                    has_par = _has_parallel_tags(text)
                    
                    if ok:
                        correct_count += 1
                    if parsed:
                        total_parsed += 1
                    if has_fa:
                        total_final_answer += 1
                    if has_par:
                        total_parallel += 1
                    total_samples += 1
                    
                    sample_results.append({
                        "sample_idx": sample_idx,
                        "pred": pred,
                        "ok": ok,
                        "parsed": parsed,
                        "has_final_answer": has_fa,
                        "has_parallel": has_par,
                        "output": text,
                    })
                
                # acc@1: first sample correct
                first_ok = sample_results[0]["ok"] if sample_results else False
                if first_ok:
                    num_correct += 1
                
                # pass@k: at least one correct
                passed = correct_count > 0
                if passed:
                    total_passed += 1
                
                total_correct_samples += correct_count
                num_total += 1

                rec: Dict[str, Any] = {
                    "idx": idx,
                    "gold": gold,
                    "problem": problem,
                    "num_samples": k,
                    "correct_count": correct_count,
                    "passed": passed,
                    "first_ok": first_ok,
                    "samples": sample_results,
                }
                fo.write(json.dumps(rec, ensure_ascii=False) + "\n")
                fo.flush()

            if num_total % 50 == 0:
                acc1 = num_correct / max(1, num_total)
                mean_k = total_correct_samples / max(1, total_samples)
                pass_k = total_passed / max(1, num_total)
                parsed_r = total_parsed / max(1, total_samples)
                print(f"[INFO] progress {num_total}/{len(df)} acc@1={acc1:.4f} mean@{k}={mean_k:.4f} pass@{k}={pass_k:.4f} parsed={parsed_r:.3f}", flush=True)

    seconds = time.time() - start
    
    acc1 = num_correct / max(1, num_total)
    mean_k = total_correct_samples / max(1, total_samples)
    pass_k = total_passed / max(1, num_total)
    parsed_r = total_parsed / max(1, total_samples)
    fa_r = total_final_answer / max(1, total_samples)
    par_r = total_parallel / max(1, total_samples)
    
    summary = EvalSummary(
        timestamp=_now_ts(),
        model_path=cfg.model_path,
        data_parquet=cfg.data_parquet,
        limit=cfg.limit,
        batch_size=cfg.batch_size,
        max_new_tokens=cfg.max_new_tokens,
        num_samples=k,
        do_sample=cfg.do_sample,
        temperature=cfg.temperature,
        top_p=cfg.top_p,
        top_k=cfg.top_k,
        num_total=num_total,
        num_correct=num_correct,
        accuracy=acc1,
        mean_at_k=mean_k,
        pass_at_k=pass_k,
        parsed_ratio=parsed_r,
        final_answer_ratio=fa_r,
        parallel_ratio=par_r,
        seconds=seconds,
    )

    with open(out_summary, "w", encoding="utf-8") as f:
        json.dump(asdict(summary), f, ensure_ascii=False, indent=2)

    print(f"[DONE] acc@1={acc1:.4f} ({num_correct}/{num_total}) mean@{k}={mean_k:.4f} pass@{k}={pass_k:.4f} parallel_ratio={par_r:.3f}", flush=True)
    print(f"[DONE] wrote: {out_summary}", flush=True)


if __name__ == "__main__":
    main()
