#!/usr/bin/env python3
"""
MedQA (multiple-choice) accuracy evaluation for Parallel-R1 checkpoints.

Input parquet should follow the Parallel-R1 schema, especially:
- extra_info.question (string prompt)
- reward_model.ground_truth (choice key like A/B/C/D/E)

Outputs:
- predictions.jsonl: per-sample record (gold/pred/output)
- summary.json: aggregated accuracy
- config.json: evaluation config
"""

from __future__ import annotations

import argparse
import json
import os
import re
import time
from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Optional

import pandas as pd
import torch
from transformers import AutoModel, AutoModelForCausalLM, AutoTokenizer


CHOICE_RE = re.compile(r"\b([A-E])\b")
PARALLEL_TAG_RE = re.compile(r"<\s*/?\s*parallel\s*>", flags=re.IGNORECASE)
FINAL_ANSWER_LINE_RE = re.compile(r"(?is)\n?\s*Final Answer\s*:\s*[A-E]\s*\n?")


def _now_ts() -> str:
    return time.strftime("%Y%m%d_%H%M%S", time.localtime())


def _ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def _get_question(row: pd.Series) -> str:
    extra = row.get("extra_info", None)
    if isinstance(extra, dict) and "question" in extra:
        return str(extra["question"])
    # fallback to 'question' column if present
    if "question" in row:
        return str(row["question"])
    raise ValueError("Cannot find question in row (expected extra_info.question).")


def _get_gold(row: pd.Series) -> Optional[str]:
    rm = row.get("reward_model", None)
    if isinstance(rm, dict) and "ground_truth" in rm:
        g = str(rm["ground_truth"]).strip().upper()
        if g in {"A", "B", "C", "D", "E"}:
            return g
    # fallback to answer_idx column
    if "answer_idx" in row and isinstance(row["answer_idx"], str):
        g = row["answer_idx"].strip().upper()
        if g in {"A", "B", "C", "D", "E"}:
            return g
    return None


def build_prompt(question: str) -> str:
    # The dataset question already includes instructions + options.
    # Append a strict output requirement to make extraction robust.
    return (
        question.rstrip()
        + "\n\n"
        + "Return ONLY the final option letter in the format:\n"
        + "Final Answer: <A/B/C/D/E>\n"
    )


def extract_pred_choice(text: str) -> Optional[str]:
    """
    Priority:
    1) 'Final Answer: X'
    2) last standalone choice letter A-E in the output
    """
    if not text:
        return None
    m = re.search(r"Final Answer:\s*([A-E])", text, flags=re.IGNORECASE)
    if m:
        return m.group(1).upper()
    ms = list(CHOICE_RE.finditer(text.upper()))
    if ms:
        return ms[-1].group(1).upper()
    return None


def _strip_final_answer_line(text: str) -> str:
    return FINAL_ANSWER_LINE_RE.sub("\n", text or "").strip()


def _mean_pool(last_hidden: torch.Tensor, attn_mask: torch.Tensor) -> torch.Tensor:
    mask = attn_mask.unsqueeze(-1).to(last_hidden.dtype)
    summed = (last_hidden * mask).sum(dim=1)
    denom = mask.sum(dim=1).clamp(min=1e-6)
    return summed / denom


@torch.no_grad()
def _encode_texts(encoder_tokenizer, encoder_model, texts: List[str], max_length: int, device: torch.device) -> torch.Tensor:
    tok = encoder_tokenizer(
        texts,
        padding=True,
        truncation=True,
        max_length=max_length,
        return_tensors="pt",
    )
    tok = {k: v.to(device) for k, v in tok.items()}
    out = encoder_model(**tok)
    emb = _mean_pool(out.last_hidden_state, tok["attention_mask"])
    emb = torch.nn.functional.normalize(emb, p=2, dim=-1)
    return emb.detach().cpu()


def _sds_from_emb(emb: torch.Tensor) -> float:
    m = emb.shape[0]
    if m <= 1:
        return 0.0
    sim = emb @ emb.t()
    off = sim[~torch.eye(m, dtype=torch.bool)]
    return float(1.0 - off.mean().item())


@dataclass
class EvalConfig:
    model_path: str
    data_parquet: str
    out_dir: str
    limit: int
    batch_size: int
    max_new_tokens: int
    num_samples: int
    do_sample: bool
    temperature: float
    top_p: float
    top_k: int
    seed: int
    cuda_visible_devices: str
    encoder_model_path: str
    encoder_device: str
    encoder_max_length: int


@dataclass
class EvalSummary:
    timestamp: str
    model_path: str
    data_parquet: str
    limit: int
    batch_size: int
    max_new_tokens: int
    num_samples: int
    do_sample: bool
    temperature: float
    top_p: float
    top_k: int
    num_total: int
    num_correct: int
    accuracy: float
    mean_at_k: float
    pass_at_k: float
    parsed_ratio: float
    final_answer_ratio: float
    parallel_ratio: float
    avg_response_tokens: float
    token_efficiency: float
    sds_mean: float
    seconds: float


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model_path", required=True)
    ap.add_argument("--data_parquet", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--limit", type=int, default=0, help="0 = full dataset")
    ap.add_argument("--batch_size", type=int, default=4)
    ap.add_argument("--max_new_tokens", type=int, default=64)
    ap.add_argument("--num_samples", type=int, default=1, help="k for Mean@k / Pass@k (1 = greedy/single)")
    ap.add_argument("--do_sample", action="store_true", help="Enable sampling (otherwise greedy).")
    ap.add_argument("--temperature", type=float, default=1.0)
    ap.add_argument("--top_p", type=float, default=1.0)
    ap.add_argument("--top_k", type=int, default=0, help="0 disables top-k. (HF does not use -1 like vLLM)")
    ap.add_argument("--seed", type=int, default=0, help="0 means no manual seed")
    ap.add_argument("--encoder_model_path", type=str, default="", help="Optional: HF path for SDS (e.g. PubMedBERT).")
    ap.add_argument("--encoder_device", type=str, default="cpu", help="cpu / cuda / cuda:0 ...")
    ap.add_argument("--encoder_max_length", type=int, default=256)
    args = ap.parse_args()

    cfg = EvalConfig(
        model_path=args.model_path,
        data_parquet=args.data_parquet,
        out_dir=args.out_dir,
        limit=args.limit,
        batch_size=args.batch_size,
        max_new_tokens=args.max_new_tokens,
        num_samples=max(1, int(args.num_samples)),
        do_sample=bool(args.do_sample),
        temperature=float(args.temperature),
        top_p=float(args.top_p),
        top_k=int(args.top_k),
        seed=int(args.seed),
        cuda_visible_devices=os.environ.get("CUDA_VISIBLE_DEVICES", ""),
        encoder_model_path=str(args.encoder_model_path),
        encoder_device=str(args.encoder_device),
        encoder_max_length=int(args.encoder_max_length),
    )

    _ensure_dir(cfg.out_dir)
    out_jsonl = os.path.join(cfg.out_dir, "predictions.jsonl")
    out_summary = os.path.join(cfg.out_dir, "summary.json")
    out_config = os.path.join(cfg.out_dir, "config.json")

    with open(out_config, "w", encoding="utf-8") as f:
        json.dump(asdict(cfg), f, ensure_ascii=False, indent=2)

    df = pd.read_parquet(cfg.data_parquet)
    if cfg.limit and cfg.limit > 0:
        df = df.iloc[: cfg.limit].copy()

    print(f"[INFO] Loading model from {cfg.model_path}", flush=True)
    model = AutoModelForCausalLM.from_pretrained(
        cfg.model_path, torch_dtype=torch.bfloat16, device_map="auto"
    )
    try:
        tok = AutoTokenizer.from_pretrained(cfg.model_path, fix_mistral_regex=True)
    except TypeError:
        tok = AutoTokenizer.from_pretrained(cfg.model_path)

    # decoder-only batching: left padding
    tok.padding_side = "left"
    if tok.pad_token_id is None and tok.eos_token_id is not None:
        tok.pad_token_id = tok.eos_token_id

    model.eval()

    # Optional encoder for SDS
    enc_tok = None
    enc_model = None
    enc_device = torch.device(cfg.encoder_device)
    if cfg.encoder_model_path:
        print(f"[INFO] Loading encoder for SDS from {cfg.encoder_model_path} on {enc_device}", flush=True)
        enc_tok = AutoTokenizer.from_pretrained(cfg.encoder_model_path, use_fast=True)
        enc_model = AutoModel.from_pretrained(cfg.encoder_model_path)
        enc_model.eval()
        enc_model.to(enc_device)

    if cfg.seed:
        try:
            torch.manual_seed(cfg.seed)
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(cfg.seed)
        except Exception:
            pass

    start = time.time()
    num_total = 0
    num_correct = 0
    # Mean@k / Pass@k stats
    num_questions = 0
    sum_mean_at_k = 0.0
    num_pass_at_k = 0
    # extraction/format diagnostics across all generations
    num_parsed = 0
    num_final_answer = 0
    num_parallel = 0
    total_generations = 0
    total_response_tokens = 0
    # SDS across questions (needs k>1 and encoder)
    sds_sum = 0.0
    sds_cnt = 0

    with open(out_jsonl, "w", encoding="utf-8") as fo:
        idxs = list(df.index)
        for off in range(0, len(idxs), cfg.batch_size):
            batch_idxs = idxs[off : off + cfg.batch_size]
            prompts: List[str] = []
            golds: List[Optional[str]] = []

            for idx in batch_idxs:
                row = df.loc[idx]
                q = _get_question(row)
                prompts.append(build_prompt(q))
                golds.append(_get_gold(row))

            inputs = tok(prompts, return_tensors="pt", padding=True, truncation=True).to(model.device)
            with torch.inference_mode():
                gen_kwargs: Dict[str, Any] = dict(
                    **inputs,
                    max_new_tokens=cfg.max_new_tokens,
                    pad_token_id=tok.eos_token_id,
                )
                if cfg.num_samples > 1:
                    gen_kwargs["num_return_sequences"] = cfg.num_samples
                # sampling controls
                gen_kwargs["do_sample"] = bool(cfg.do_sample) if cfg.num_samples > 1 else bool(cfg.do_sample)
                if gen_kwargs["do_sample"]:
                    gen_kwargs["temperature"] = cfg.temperature
                    gen_kwargs["top_p"] = cfg.top_p
                    gen_kwargs["top_k"] = cfg.top_k
                out = model.generate(**gen_kwargs)

            # decode twice: keep specials for tag detection; skip specials for answer extraction robustness
            texts_raw = tok.batch_decode(out, skip_special_tokens=False)
            texts_clean = tok.batch_decode(out, skip_special_tokens=True)
            # response token length accounting (works with left padding)
            # out: (bs*ns, seq_len). inputs.attention_mask: (bs, in_len)
            in_lens = inputs["attention_mask"].sum(dim=-1).tolist()  # per original prompt
            # repeat each input length for num_return_sequences
            in_lens_rep = []
            for l in in_lens:
                in_lens_rep.extend([int(l)] * ns)
            for seq, in_len in zip(out, in_lens_rep, strict=True):
                total_response_tokens += max(0, int(seq.numel()) - int(in_len))

            # HF generate returns: (bs * num_return_sequences, seq_len)
            # group back to per-question
            ns = cfg.num_samples
            assert len(texts_clean) == len(batch_idxs) * ns, (len(texts_clean), len(batch_idxs), ns)

            for qi, (idx, gold) in enumerate(zip(batch_idxs, golds)):
                start_i = qi * ns
                end_i = start_i + ns
                outs_raw = texts_raw[start_i:end_i]
                outs_clean = texts_clean[start_i:end_i]

                oks: List[int] = []
                for si, (text_raw, text_clean) in enumerate(zip(outs_raw, outs_clean)):
                    pred = extract_pred_choice(text_clean)
                    ok = bool(pred is not None and gold is not None and pred == gold)
                    oks.append(int(ok))

                    total_generations += 1
                    num_parsed += int(pred is not None)
                    num_final_answer += int(bool(re.search(r"Final Answer:\s*[A-E]", text_clean, flags=re.IGNORECASE)))
                    num_parallel += int(bool(PARALLEL_TAG_RE.search(text_raw) or ("<Parallel>" in text_raw) or ("</Parallel>" in text_raw)))

                    rec: Dict[str, Any] = {
                        "idx": int(idx),
                        "sample_id": int(si),
                        "gold": gold,
                        "pred": pred,
                        "ok": ok,
                        "output": text_clean,
                    }
                    fo.write(json.dumps(rec, ensure_ascii=False) + "\n")

                # SDS per question (over k samples)
                if enc_tok is not None and enc_model is not None and len(outs_clean) > 1:
                    sds_texts = [_strip_final_answer_line(t) for t in outs_clean]
                    emb = _encode_texts(enc_tok, enc_model, sds_texts, cfg.encoder_max_length, enc_device)
                    sds_sum += _sds_from_emb(emb)
                    sds_cnt += 1

                # per-question aggregation
                num_questions += 1
                mean_k = float(sum(oks) / max(1, len(oks)))
                pass_k = bool(sum(oks) > 0)
                sum_mean_at_k += mean_k
                num_pass_at_k += int(pass_k)

                # keep compatibility: also report "accuracy" as Mean@1 (first sample), if available
                num_total += 1
                num_correct += int(oks[0] if oks else 0)

            fo.flush()

            if num_questions and (num_questions % 50 == 0):
                acc1 = num_correct / max(1, num_total)
                mean_at_k = sum_mean_at_k / max(1, num_questions)
                pass_at_k = num_pass_at_k / max(1, num_questions)
                parsed_ratio = num_parsed / max(1, total_generations)
                print(
                    f"[INFO] progress {num_questions}/{len(df)} "
                    f"acc@1={acc1:.4f} mean@{cfg.num_samples}={mean_at_k:.4f} pass@{cfg.num_samples}={pass_at_k:.4f} "
                    f"parsed={parsed_ratio:.3f}",
                    flush=True,
                )

    seconds = time.time() - start
    mean_at_k = sum_mean_at_k / max(1, num_questions)
    pass_at_k = num_pass_at_k / max(1, num_questions)
    parsed_ratio = num_parsed / max(1, total_generations)
    final_answer_ratio = num_final_answer / max(1, total_generations)
    parallel_ratio = num_parallel / max(1, total_generations)
    avg_resp_tokens = total_response_tokens / max(1, total_generations)
    token_eff = (num_correct / max(1, num_total)) / max(1e-9, avg_resp_tokens)
    sds_mean = (sds_sum / max(1, sds_cnt)) if sds_cnt > 0 else 0.0
    summary = EvalSummary(
        timestamp=_now_ts(),
        model_path=cfg.model_path,
        data_parquet=cfg.data_parquet,
        limit=cfg.limit,
        batch_size=cfg.batch_size,
        max_new_tokens=cfg.max_new_tokens,
        num_samples=cfg.num_samples,
        do_sample=cfg.do_sample,
        temperature=cfg.temperature,
        top_p=cfg.top_p,
        top_k=cfg.top_k,
        num_total=num_total,
        num_correct=num_correct,
        accuracy=(num_correct / max(1, num_total)),
        mean_at_k=mean_at_k,
        pass_at_k=pass_at_k,
        parsed_ratio=parsed_ratio,
        final_answer_ratio=final_answer_ratio,
        parallel_ratio=parallel_ratio,
        avg_response_tokens=float(avg_resp_tokens),
        token_efficiency=float(token_eff),
        sds_mean=float(sds_mean),
        seconds=seconds,
    )

    with open(out_summary, "w", encoding="utf-8") as f:
        json.dump(asdict(summary), f, ensure_ascii=False, indent=2)

    print(
        f"[DONE] acc@1={summary.accuracy:.4f} ({summary.num_correct}/{summary.num_total}) "
        f"mean@{summary.num_samples}={summary.mean_at_k:.4f} pass@{summary.num_samples}={summary.pass_at_k:.4f} "
        f"parallel_ratio={summary.parallel_ratio:.3f}",
        flush=True,
    )
    print(f"[DONE] wrote: {out_summary}", flush=True)


if __name__ == "__main__":
    main()


