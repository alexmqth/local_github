# verl H800 Bundle（可直接跑：Phase1/Phase2/可选 Phase3）

本目录用于把 **Parallel-R1 的 verl 代码**打包成一个可上传到 H800 的“即用版”（不包含模型和数据）。

你需要在 H800 上已准备好：
- **Teacher 模型**（例如 HuatuoGPT-o1-8B）
- **Student 模型**（例如 Qwen2.5-14B-Instruct 或你的 SFT checkpoint）
- **MedQA v2 parquet**（`train/valid/test.parquet`，题干包含 A/B/C/D 选项）

---

## 1) 一键创建环境（推荐）

在 `verl/` 目录下执行：

```bash
bash h800_bundle/setup_core.sh
```

它会创建 `./.venv_h800` 并安装 Phase1 + SFT 需要的最小依赖（**不包含 flash-attn/liger-kernel/wandb**，避免编译和登录问题）。

> 如果你已经在 H800 上有现成的 python 环境（例如 `.venv` / conda env）并且不想新建 venv：
> - 直接在当前环境里安装：`pip install -r verl/h800_bundle/requirements_core.txt && pip install -e verl`
> - 或者运行脚本时不创建 venv：脚本找不到 `.venv_h800` 会自动使用“当前 python 环境”（并打印 WARN）。

> 如果你未来要跑 Phase3 RL（Ray/vLLM），再执行：
>
> ```bash
> bash h800_bundle/setup_rl_extra.sh
> ```

---

## 2) Phase1：8 卡并行生成（Cold-Start）

示例（8×H800，seed=42，3 pass）：

```bash
bash h800_bundle/run_phase1_generate.sh \
  --gpus 0,1,2,3,4,5,6,7 \
  --teacher_model /ABS/PATH/HuatuoGPT-o1-8B \
  --medqa_train_parquet /ABS/PATH/medqa_us_4options_parallel_v2/train.parquet \
  --output_dir /ABS/PATH/coldstart_raw_v2_huatuo \
  --num_passes 3 \
  --batch_size 4 \
  --max_new_tokens 1024 \
  --seed 42
```

输出会是：
`output_dir/shard0/pass_0.jsonl ... output_dir/shard7/pass_2.jsonl`

---

## 3) Phase1 清洗（输出 SFT parquet）

```bash
bash h800_bundle/run_phase1_clean.sh \
  --input_dir /ABS/PATH/coldstart_raw_v2_huatuo \
  --output_dir /ABS/PATH/coldstart_sft_v2_huatuo_nodedupe \
  --min_paths 2
```

产物：
- `output_dir/train.parquet`
- `output_dir/stats.json`

> 说明：清洗脚本会递归读取 `**/pass_*.jsonl`，所以无需手工合并 shard。

---

## 4) Phase2：SFT（默认 LoRA，避免 OOM）

推荐（8 卡，LoRA rank=64，global batch=64，logger=console）：

```bash
bash h800_bundle/run_sft_lora.sh \
  --gpus 0,1,2,3,4,5,6,7 \
  --student_model /ABS/PATH/Qwen2.5-14B-Instruct \
  --train_parquet /ABS/PATH/coldstart_sft_v2_huatuo_nodedupe/train.parquet \
  --valid_parquet /ABS/PATH/medqa_us_4options_parallel_v2/valid.parquet
```

训练输出默认在：
`verl/Parallel-R1/MedQA-SFT-ColdStart_YYYYMMDD_HHMMSS/`

---

## 5) （可选）Phase3：D-CRPO RL

Phase3 依赖更多（Ray/vLLM/encoder），建议先跑通 Phase2 再做。

---

## 6) 常见问题

### Q: 我已经有 vllm_env / 其它 venv，会冲突吗？
不会。只要你用 `.venv_h800` 里的 python 运行即可（脚本会自动激活）。

### Q: 为什么不安装 flash-attn？
为了避免在集群上编译失败/版本冲突。我们已把 SFT trainer 的 flash-attn 依赖改为“可选”，默认配置不需要它。


