#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERL_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
VENV_DIR="${VENV_DIR:-${VERL_DIR}/.venv_h800}"

INPUT_DIR=""
OUTPUT_DIR=""
MIN_PATHS=2
DEDUPE="false"

usage() {
  echo "Usage:"
  echo "  bash h800_bundle/run_phase1_clean.sh --input_dir /ABS/PATH/coldstart_raw --output_dir /ABS/PATH/coldstart_sft --min_paths 2 [--dedupe]"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --input_dir) INPUT_DIR="$2"; shift 2;;
    --output_dir) OUTPUT_DIR="$2"; shift 2;;
    --min_paths) MIN_PATHS="$2"; shift 2;;
    --dedupe) DEDUPE="true"; shift 1;;
    -h|--help) usage; exit 0;;
    *) echo "Unknown arg: $1"; usage; exit 1;;
  esac
done

if [[ -z "${INPUT_DIR}" || -z "${OUTPUT_DIR}" ]]; then
  echo "[run_phase1_clean] missing required args."
  usage
  exit 1
fi

if [[ -d "${VENV_DIR}" ]]; then
  # shellcheck disable=SC1090
  source "${VENV_DIR}/bin/activate"
else
  echo "[run_phase1_clean][WARN] venv not found: ${VENV_DIR}"
  echo "[run_phase1_clean][WARN] using current python environment."
fi

cmd=(python "${VERL_DIR}/data_preprocess_scripts/phase1_clean_coldstart.py"
  --input_dir "${INPUT_DIR}"
  --output_dir "${OUTPUT_DIR}"
  --min_paths "${MIN_PATHS}"
)
if [[ "${DEDUPE}" == "true" ]]; then
  cmd+=(--dedupe)
fi

echo "[run_phase1_clean] ${cmd[*]}"
exec "${cmd[@]}"


