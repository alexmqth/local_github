#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERL_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
VENV_DIR="${VENV_DIR:-${VERL_DIR}/.venv_h800}"

# defaults
GPUS="0,1,2,3,4,5,6,7"
NUM_PASSES=3
PASS_IDS=""
BATCH_SIZE=4
MAX_NEW_TOKENS=1024
MAX_INPUT_LENGTH=2048
TEMPERATURE=0.7
TOP_P=0.9
SEED=42
LOG_DIR=""

TEACHER_MODEL=""
MEDQA_TRAIN_PARQUET=""
OUTPUT_DIR=""

usage() {
  echo "Usage:"
  echo "  bash h800_bundle/run_phase1_generate.sh \\"
  echo "    --gpus 0,1,2,3,4,5,6,7 \\"
  echo "    --teacher_model /ABS/PATH/HuatuoGPT-o1-8B \\"
  echo "    --medqa_train_parquet /ABS/PATH/train.parquet \\"
  echo "    --output_dir /ABS/PATH/coldstart_raw \\"
  echo "    [--num_passes 3] [--pass_ids 0,1,2] [--batch_size 4] [--max_new_tokens 1024] [--seed 42]"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --gpus) GPUS="$2"; shift 2;;
    --teacher_model) TEACHER_MODEL="$2"; shift 2;;
    --medqa_train_parquet) MEDQA_TRAIN_PARQUET="$2"; shift 2;;
    --output_dir) OUTPUT_DIR="$2"; shift 2;;
    --num_passes) NUM_PASSES="$2"; shift 2;;
    --pass_ids) PASS_IDS="$2"; shift 2;;
    --batch_size) BATCH_SIZE="$2"; shift 2;;
    --max_new_tokens) MAX_NEW_TOKENS="$2"; shift 2;;
    --max_input_length) MAX_INPUT_LENGTH="$2"; shift 2;;
    --temperature) TEMPERATURE="$2"; shift 2;;
    --top_p) TOP_P="$2"; shift 2;;
    --seed) SEED="$2"; shift 2;;
    --log_dir) LOG_DIR="$2"; shift 2;;
    -h|--help) usage; exit 0;;
    *) echo "Unknown arg: $1"; usage; exit 1;;
  esac
done

if [[ -z "${TEACHER_MODEL}" || -z "${MEDQA_TRAIN_PARQUET}" || -z "${OUTPUT_DIR}" ]]; then
  echo "[run_phase1_generate] missing required args."
  usage
  exit 1
fi

if [[ -z "${LOG_DIR}" ]]; then
  LOG_DIR="${OUTPUT_DIR}/logs"
fi
mkdir -p "${LOG_DIR}"

if [[ -d "${VENV_DIR}" ]]; then
  # shellcheck disable=SC1090
  source "${VENV_DIR}/bin/activate"
else
  echo "[run_phase1_generate][WARN] venv not found: ${VENV_DIR}"
  echo "[run_phase1_generate][WARN] using current python environment."
fi

echo "[run_phase1_generate] gpus=${GPUS}"
echo "[run_phase1_generate] teacher_model=${TEACHER_MODEL}"
echo "[run_phase1_generate] medqa_train_parquet=${MEDQA_TRAIN_PARQUET}"
echo "[run_phase1_generate] output_dir=${OUTPUT_DIR}"
echo "[run_phase1_generate] num_passes=${NUM_PASSES} pass_ids=${PASS_IDS:-<auto>}"

python "${VERL_DIR}/data_preprocess_scripts/phase1_generate_coldstart_multigpu.py" \
  --mode orchestrate \
  --gpus "${GPUS}" \
  --model_path "${TEACHER_MODEL}" \
  --medqa_parquet "${MEDQA_TRAIN_PARQUET}" \
  --output_dir "${OUTPUT_DIR}" \
  --num_passes "${NUM_PASSES}" \
  ${PASS_IDS:+--pass_ids "${PASS_IDS}"} \
  --batch_size "${BATCH_SIZE}" \
  --max_new_tokens "${MAX_NEW_TOKENS}" \
  --max_input_length "${MAX_INPUT_LENGTH}" \
  --temperature "${TEMPERATURE}" \
  --top_p "${TOP_P}" \
  --seed "${SEED}" \
  --log_dir "${LOG_DIR}"


