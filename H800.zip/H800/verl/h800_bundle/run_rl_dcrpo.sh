#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERL_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
VENV_DIR="${VENV_DIR:-${VERL_DIR}/.venv_h800}"

if [[ ! -d "${VENV_DIR}" ]]; then
  echo "[run_rl_dcrpo] venv not found: ${VENV_DIR}"
  echo "[run_rl_dcrpo] please run: bash h800_bundle/setup_core.sh && bash h800_bundle/setup_rl_extra.sh"
  exit 1
fi

GPUS="0,1,2,3,4,5,6,7"
SFT_CKPT=""
TRAIN_PARQUET=""
VALID_PARQUET=""
ENCODER_MODEL=""
ENCODER_DEVICE="cpu"

usage() {
  echo "Usage:"
  echo "  bash h800_bundle/run_rl_dcrpo.sh \\"
  echo "    --gpus 0,1,2,3,4,5,6,7 \\"
  echo "    --sft_ckpt /ABS/PATH/your_sft_ckpt \\"
  echo "    --train_parquet /ABS/PATH/train.parquet \\"
  echo "    --valid_parquet /ABS/PATH/valid.parquet \\"
  echo "    --encoder_model /ABS/PATH/PubMedBERT \\"
  echo "    [--encoder_device cpu|cuda:7]"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --gpus) GPUS="$2"; shift 2;;
    --sft_ckpt) SFT_CKPT="$2"; shift 2;;
    --train_parquet) TRAIN_PARQUET="$2"; shift 2;;
    --valid_parquet) VALID_PARQUET="$2"; shift 2;;
    --encoder_model) ENCODER_MODEL="$2"; shift 2;;
    --encoder_device) ENCODER_DEVICE="$2"; shift 2;;
    -h|--help) usage; exit 0;;
    *) echo "Unknown arg: $1"; usage; exit 1;;
  esac
done

if [[ -z "${SFT_CKPT}" || -z "${TRAIN_PARQUET}" || -z "${VALID_PARQUET}" || -z "${ENCODER_MODEL}" ]]; then
  echo "[run_rl_dcrpo] missing required args."
  usage
  exit 1
fi

# shellcheck disable=SC1090
source "${VENV_DIR}/bin/activate"

export CUDA_VISIBLE_DEVICES="${GPUS}"
cd "${VERL_DIR}"

# Override paths from training script (keep script logic unchanged)
bash training_scripts/rl_medqa_dcrpo.sh \
  "data.train_files=['${TRAIN_PARQUET}']" \
  "data.val_files=['${VALID_PARQUET}']" \
  "actor_rollout_ref.model.path=${SFT_CKPT}" \
  "reward_model.reward_kwargs.encoder_model_path=${ENCODER_MODEL}" \
  "reward_model.reward_kwargs.encoder_device=${ENCODER_DEVICE}"


