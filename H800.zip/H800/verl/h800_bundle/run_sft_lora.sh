#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERL_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
VENV_DIR="${VENV_DIR:-${VERL_DIR}/.venv_h800}"

GPUS="0,1,2,3,4,5,6,7"
NPROC_PER_NODE=8
TRAIN_BATCH_SIZE=64
MAX_LENGTH=2048
LR=2e-5

LORA_RANK=64
LORA_ALPHA=16

STUDENT_MODEL=""
TRAIN_PARQUET=""
VALID_PARQUET=""

usage() {
  echo "Usage:"
  echo "  bash h800_bundle/run_sft_lora.sh \\"
  echo "    --gpus 0,1,2,3,4,5,6,7 \\"
  echo "    --student_model /ABS/PATH/Qwen2.5-14B-Instruct \\"
  echo "    --train_parquet /ABS/PATH/train.parquet \\"
  echo "    --valid_parquet /ABS/PATH/valid.parquet"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --gpus) GPUS="$2"; shift 2;;
    --nproc_per_node) NPROC_PER_NODE="$2"; shift 2;;
    --train_batch_size) TRAIN_BATCH_SIZE="$2"; shift 2;;
    --max_length) MAX_LENGTH="$2"; shift 2;;
    --lr) LR="$2"; shift 2;;
    --lora_rank) LORA_RANK="$2"; shift 2;;
    --lora_alpha) LORA_ALPHA="$2"; shift 2;;
    --student_model) STUDENT_MODEL="$2"; shift 2;;
    --train_parquet) TRAIN_PARQUET="$2"; shift 2;;
    --valid_parquet) VALID_PARQUET="$2"; shift 2;;
    -h|--help) usage; exit 0;;
    *) echo "Unknown arg: $1"; usage; exit 1;;
  esac
done

if [[ -z "${STUDENT_MODEL}" || -z "${TRAIN_PARQUET}" || -z "${VALID_PARQUET}" ]]; then
  echo "[run_sft_lora] missing required args."
  usage
  exit 1
fi

if [[ -d "${VENV_DIR}" ]]; then
  # shellcheck disable=SC1090
  source "${VENV_DIR}/bin/activate"
else
  echo "[run_sft_lora][WARN] venv not found: ${VENV_DIR}"
  echo "[run_sft_lora][WARN] using current python environment."
fi

export CUDA_VISIBLE_DEVICES="${GPUS}"
export NPROC_PER_NODE="${NPROC_PER_NODE}"
export TRAIN_BATCH_SIZE="${TRAIN_BATCH_SIZE}"
export MAX_LENGTH="${MAX_LENGTH}"
export LR="${LR}"
export TRAIN_DATA="${TRAIN_PARQUET}"
export VAL_DATA="${VALID_PARQUET}"
export MODEL_PATH="${STUDENT_MODEL}"

# Avoid fragmentation OOM
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

cd "${VERL_DIR}"

bash training_scripts/sft_medqa_coldstart.sh \
  "trainer.logger=['console']" \
  "model.lora_rank=${LORA_RANK}" \
  "model.lora_alpha=${LORA_ALPHA}"


