#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERL_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

VENV_DIR="${VENV_DIR:-${VERL_DIR}/.venv_h800}"
PYTHON_BIN="${PYTHON_BIN:-python3}"
VENV_SYSTEM_SITE_PACKAGES="${VENV_SYSTEM_SITE_PACKAGES:-1}"

echo "[setup_core] VERL_DIR=${VERL_DIR}"
echo "[setup_core] VENV_DIR=${VENV_DIR}"

if [[ ! -d "${VENV_DIR}" ]]; then
  echo "[setup_core] creating venv..."
  if [[ "${VENV_SYSTEM_SITE_PACKAGES}" == "1" ]]; then
    "${PYTHON_BIN}" -m venv --system-site-packages "${VENV_DIR}"
  else
    "${PYTHON_BIN}" -m venv "${VENV_DIR}"
  fi
fi

# shellcheck disable=SC1090
source "${VENV_DIR}/bin/activate"

python -m pip install -U pip wheel setuptools

echo "[setup_core] installing requirements_core.txt ..."
python -m pip install -r "${SCRIPT_DIR}/requirements_core.txt"

echo "[setup_core] installing verl (editable) ..."
python -m pip install -e "${VERL_DIR}"

python - <<'PY'
try:
    import torch
    print("[setup_core] torch:", getattr(torch, "__version__", None), "cuda_available:", torch.cuda.is_available())
except Exception as e:
    print("[setup_core][WARN] torch not available in this venv:", repr(e))
    print("[setup_core][WARN] Please ensure you have a CUDA-enabled torch for H800 before running training.")
PY

echo "[setup_core] DONE."


