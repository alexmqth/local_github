#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERL_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

VENV_DIR="${VENV_DIR:-${VERL_DIR}/.venv_h800}"

if [[ ! -d "${VENV_DIR}" ]]; then
  echo "[setup_rl_extra] venv not found: ${VENV_DIR}"
  echo "[setup_rl_extra] please run: bash h800_bundle/setup_core.sh"
  exit 1
fi

# shellcheck disable=SC1090
source "${VENV_DIR}/bin/activate"

python -m pip install -U pip
python -m pip install -r "${SCRIPT_DIR}/requirements_rl_extra.txt"

echo "[setup_rl_extra] DONE."


