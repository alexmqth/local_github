#!/usr/bin/env python3
"""
Phase 1: Clean & Filter Cold-Start Data

D-CRPO.pdf 清洗标准：
- 仅保留 Final Answer 正确的数据
- 且包含完整 <Parallel>...</Parallel> 标签
- 且至少包含 2 条 <Path>...</Path>

输出：
- SFT parquet（符合 ParallelThinkingSFTDataset schema）
- 统计信息

用法：
    python phase1_clean_coldstart.py \
        --input_dir ./data/med_qa/coldstart_raw \
        --output_dir ./data/med_qa/coldstart_sft_v1 \
        --min_paths 2
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import re
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd


def extract_final_answer(text: str) -> Optional[str]:
    """从生成文本中提取 Final Answer"""
    # 优先匹配 "Final Answer: X" 格式
    m = re.search(r"Final Answer:\s*([A-Ea-e])", text, re.IGNORECASE)
    if m:
        return m.group(1).upper()
    # fallback: 最后一个独立的选项字母
    matches = list(re.finditer(r"\b([A-Ea-e])\b", text))
    if matches:
        return matches[-1].group(1).upper()
    return None


def count_paths(text: str) -> int:
    """统计 <Path>...</Path> 的数量"""
    # 简单计数 <Path> 标签
    return len(re.findall(r"<Path>", text, re.IGNORECASE))


def has_complete_parallel_structure(text: str) -> bool:
    """检查是否有完整的 <Parallel>...</Parallel> 结构"""
    has_start = bool(re.search(r"<Parallel>", text, re.IGNORECASE))
    has_end = bool(re.search(r"</Parallel>", text, re.IGNORECASE))
    return has_start and has_end


def has_summary(text: str) -> bool:
    """检查是否有 <Summary>...</Summary>"""
    has_start = bool(re.search(r"<Summary>", text, re.IGNORECASE))
    has_end = bool(re.search(r"</Summary>", text, re.IGNORECASE))
    return has_start and has_end


def validate_record(record: Dict[str, Any], min_paths: int = 2) -> Tuple[bool, Dict[str, Any]]:
    """
    验证单条记录是否满足 D-CRPO 清洗标准
    
    Returns:
        (is_valid, stats_dict)
    """
    response = record.get("response", "")
    gt = str(record.get("ground_truth", "")).strip().upper()
    
    stats = {
        "has_response": bool(response),
        "has_ground_truth": bool(gt),
        "pred": None,
        "correct": False,
        "has_parallel": False,
        "has_summary": False,
        "num_paths": 0,
        "enough_paths": False,
        "valid": False,
    }
    
    if not response or not gt:
        return False, stats
    
    # 提取预测答案
    pred = extract_final_answer(response)
    stats["pred"] = pred
    stats["correct"] = (pred == gt) if pred else False
    
    # 检查结构
    stats["has_parallel"] = has_complete_parallel_structure(response)
    stats["has_summary"] = has_summary(response)
    stats["num_paths"] = count_paths(response)
    stats["enough_paths"] = stats["num_paths"] >= min_paths
    
    # 最终判定
    is_valid = (
        stats["correct"]
        and stats["has_parallel"]
        and stats["enough_paths"]
    )
    stats["valid"] = is_valid
    
    return is_valid, stats


def load_all_passes(input_dir: str) -> List[Dict[str, Any]]:
    """加载所有 pass 的 jsonl 文件"""
    all_records = []
    # Support both:
    # - input_dir/pass_*.jsonl
    # - input_dir/shard*/pass_*.jsonl (multi-GPU sharded generation)
    pattern = os.path.join(input_dir, "**", "pass_*.jsonl")
    files = sorted(glob.glob(pattern, recursive=True))
    
    if not files:
        print(f"[WARN] No pass_*.jsonl files found in {input_dir}")
        return []
    
    for fpath in files:
        print(f"[INFO] Loading {fpath}")
        with open(fpath, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                    all_records.append(rec)
                except Exception as e:
                    print(f"[WARN] Failed to parse line: {e}")
    
    return all_records


def deduplicate_by_index(records: List[Dict], prefer_valid: bool = True) -> List[Dict]:
    """
    按 index 去重，优先保留有效的记录
    如果同一个 index 有多条有效记录，保留第一条
    """
    index_to_records: Dict[int, List[Dict]] = defaultdict(list)
    for rec in records:
        idx = rec.get("index", -1)
        index_to_records[idx].append(rec)
    
    deduped = []
    for idx, recs in index_to_records.items():
        if prefer_valid:
            # 优先选择 valid=True 的
            valid_recs = [r for r in recs if r.get("_valid", False)]
            if valid_recs:
                deduped.append(valid_recs[0])
            else:
                # 都无效，取第一条
                deduped.append(recs[0])
        else:
            deduped.append(recs[0])
    
    return deduped


def main():
    parser = argparse.ArgumentParser(description="Phase 1: Clean cold-start data")
    parser.add_argument(
        "--input_dir",
        type=str,
        default="/home/maqiang/workshop/parallel-r1/verl/data_preprocess_scripts/data/med_qa/coldstart_raw",
        help="Directory containing pass_*.jsonl files",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="/home/maqiang/workshop/parallel-r1/verl/data_preprocess_scripts/data/med_qa/coldstart_sft_v1",
        help="Output directory for cleaned SFT parquet",
    )
    parser.add_argument("--min_paths", type=int, default=2, help="Minimum number of <Path> blocks required")
    parser.add_argument("--data_source", type=str, default="MedQA-ColdStart", help="data_source field value")
    parser.add_argument("--dedupe", action="store_true", help="Deduplicate by index (keep first valid per index)")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    # 加载所有 pass
    print(f"[INFO] Loading data from {args.input_dir}")
    all_records = load_all_passes(args.input_dir)
    print(f"[INFO] Loaded {len(all_records)} total records")

    if not all_records:
        print("[ERROR] No records found. Please run phase1_generate_coldstart.py first.")
        return

    # 验证并统计
    valid_records = []
    stats_agg = defaultdict(int)
    
    for rec in all_records:
        is_valid, stats = validate_record(rec, min_paths=args.min_paths)
        rec["_valid"] = is_valid
        rec["_stats"] = stats
        
        for k, v in stats.items():
            if isinstance(v, bool) and v:
                stats_agg[k] += 1
            elif k == "num_paths":
                stats_agg["total_paths"] += v
        
        if is_valid:
            valid_records.append(rec)

    print("\n========== Validation Statistics ==========")
    print(f"Total records:      {len(all_records)}")
    print(f"Has response:       {stats_agg['has_response']}")
    print(f"Has ground_truth:   {stats_agg['has_ground_truth']}")
    print(f"Correct answer:     {stats_agg['correct']}")
    print(f"Has <Parallel>:     {stats_agg['has_parallel']}")
    print(f"Has <Summary>:      {stats_agg['has_summary']}")
    print(f"Enough paths (>={args.min_paths}): {stats_agg['enough_paths']}")
    print(f"VALID (final):      {len(valid_records)}")
    print(f"Valid rate:         {len(valid_records)/max(1,len(all_records))*100:.2f}%")
    print("============================================\n")

    if args.dedupe:
        before_dedupe = len(valid_records)
        valid_records = deduplicate_by_index(valid_records, prefer_valid=True)
        print(f"[INFO] Deduplicated: {before_dedupe} -> {len(valid_records)}")

    if not valid_records:
        print("[WARN] No valid records after filtering!")
        return

    # 转换为 SFT parquet schema
    # 符合 ParallelThinkingSFTDataset 期望的格式：
    # - extra_info.question: prompt
    # - extra_info.answer: response with parallel tags
    sft_records = []
    for rec in valid_records:
        question = rec.get("question", "")
        response = rec.get("response", "")
        gt = rec.get("ground_truth", "")
        idx = rec.get("index", 0)
        pass_id = rec.get("pass_id", 0)
        
        sft_rec = {
            "data_source": args.data_source,
            "prompt": [{"role": "user", "content": question}],
            "ability": "medical",
            "reward_model": {"style": "rule", "ground_truth": gt},
            "extra_info": {
                "split": "train",
                "index": idx,
                "question": question,
                "answer": response,  # 包含 <Parallel> 结构的完整回复
                "reward_method": "choice_accuracy_reward",
                "pass_id": pass_id,
                "num_paths": rec.get("_stats", {}).get("num_paths", 0),
            },
        }
        sft_records.append(sft_rec)

    # 保存
    df = pd.DataFrame(sft_records)
    output_path = os.path.join(args.output_dir, "train.parquet")
    df.to_parquet(output_path, index=False)
    print(f"[DONE] Saved {len(df)} records to {output_path}")

    # 保存统计信息
    stats_path = os.path.join(args.output_dir, "stats.json")
    with open(stats_path, "w", encoding="utf-8") as f:
        json.dump({
            "total_raw": len(all_records),
            "valid": len(valid_records),
            "valid_rate": len(valid_records) / max(1, len(all_records)),
            "min_paths": args.min_paths,
            "dedupe": args.dedupe,
        }, f, indent=2)
    print(f"[DONE] Saved stats to {stats_path}")

    print("\n[NEXT STEP] Run Phase 2 SFT training:")
    print(f"  bash training_scripts/sft_medqa_coldstart.sh")


if __name__ == "__main__":
    main()

